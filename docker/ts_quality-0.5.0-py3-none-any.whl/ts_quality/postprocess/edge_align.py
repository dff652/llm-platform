"""
边界对齐（Edge Alignment）— 对 VLM 模型输出的异常区间做边界精修。

算法流程：
  1. 裁剪越界索引，过滤超宽区间
  2. 覆盖率 >70% 时反转标注（正常区域变异常）
  3. 在每个区间的左右边界各取 ±window 搜索窗口
  4. 窗口内切小段，找 peak-to-peak 最大的段
  5. 窄区间：选变化更大的一侧，用均值偏离最大点做中心偏移精修
     宽区间：左右分别精修
"""

import logging

import numpy as np

logger = logging.getLogger(__name__)


def align_edges(
    values: np.ndarray,
    segments: list[list[int]],
    window: int = 100,
    narrow_threshold: int = 100,
    max_width_ratio: float = 0.4,
    seg_divisor: int | tuple[int, int] = (337, 359),
) -> list[list[int]]:
    """对异常区间的边界做精细化对齐。

    Parameters
    ----------
    values : np.ndarray
        降采样后的时序数据（如 5000 点）
    segments : list[list[int]]
        模型输出的异常区间列表，每项 [start, end]
    window : int
        边界搜索窗口大小（单侧 ±N 点），默认 100
    narrow_threshold : int
        窄区间阈值（点），区间宽度低于此值时用单侧精修，默认 100
    max_width_ratio : float
        超宽过滤比例，区间宽度超过 总长 × ratio 视为误检丢弃，默认 0.4
    seg_divisor : int | tuple[int, int]
        分段粒度，搜索窗口内段大小 = 总长 / divisor。
        传入 (lo, hi) 元组时每次调用随机取值，默认 (337, 359)

    Returns
    -------
    list[list[int]]
        对齐后的异常区间列表
    """
    if not segments or len(values) == 0:
        return segments

    n = len(values)
    if isinstance(seg_divisor, tuple):
        divisor = np.random.randint(seg_divisor[0], seg_divisor[1] + 1)
    else:
        divisor = seg_divisor
    seg_size = max(1, n // divisor)

    # Step 1: 裁剪越界 + 过滤超宽区间
    max_width = int(n * max_width_ratio)
    cleaned = []
    for seg in segments:
        if not seg or len(seg) != 2:
            continue
        s, e = int(seg[0]), int(seg[1])
        s = max(0, min(s, n - 1))
        e = max(0, min(e, n - 1))
        if s > e:
            s, e = e, s
        if abs(e - s) <= max_width:
            cleaned.append([s, e])
    cleaned.sort()

    if not cleaned:
        return []

    # Step 2: 覆盖率 >70% 时反转（模型可能标反了）
    cleaned = _maybe_invert(cleaned, n, narrow_threshold)
    if not cleaned:
        return []

    # Step 3: 计算搜索窗口（间距都 ≥100 时用更大窗口）
    gaps = [cleaned[i + 1][0] - cleaned[i][1] for i in range(len(cleaned) - 1)]
    if gaps and any(g < 100 for g in gaps):
        adj_window = window
    else:
        adj_window = max(window, 150)

    search_windows = _build_search_windows(cleaned, adj_window, n)

    # Step 4: 边界精修（含偏移修正）
    aligned = _refine_boundaries(values, search_windows, cleaned, seg_size, n, narrow_threshold)

    logger.info("edge_align: %d → %d segments, window=%d, seg_size=%d, narrow=%d, max_width=%d",
                len(segments), len(aligned), adj_window, seg_size, narrow_threshold, max_width)
    return aligned


def _maybe_invert(segments: list[list[int]], n: int, narrow_threshold: int = 100) -> list[list[int]]:
    """覆盖率 >70% 时反转标注。"""
    total_cover = sum(e - s for s, e in segments)
    if total_cover <= 0.7 * n:
        return segments

    inverted = []
    cur = 0
    for s, e in segments:
        if e - s < narrow_threshold:
            inverted.append([s, e])
        elif cur < s:
            inverted.append([cur, s])
        cur = max(cur, e)
    if cur < n:
        inverted.append([cur, n])
    return inverted


def _build_search_windows(
    segments: list[list[int]],
    window: int,
    n: int,
) -> list[list[int]]:
    """为每个区间的左右边界构建搜索窗口。返回 [left_window, right_window, ...] 交替。"""
    windows = []
    for s, e in segments:
        left_win = [max(0, s - window), min(n, s + window)]
        right_win = [max(0, e - window), min(n, e + window)]
        if left_win[1] - left_win[0] < 20:
            left_win = [max(0, left_win[1] - 20), left_win[1]]
        if right_win[1] - right_win[0] < 20:
            right_win = [max(0, right_win[1] - 20), right_win[1]]
        windows.append(left_win)
        windows.append(right_win)
    return windows


def _refine_boundaries(
    values: np.ndarray,
    search_windows: list[list[int]],
    segments: list[list[int]],
    seg_size: int,
    n: int,
    narrow_threshold: int,
) -> list[list[int]]:
    """在搜索窗口内找 ptp 最大的段，精修边界。窄区间用偏移修正。"""
    aligned = []

    for j, (s, e) in enumerate(segments):
        left_win = search_windows[2 * j]
        right_win = search_windows[2 * j + 1]

        left_region = values[left_win[0]:left_win[1]]
        right_region = values[right_win[0]:right_win[1]]

        left_chunks = _split_and_ptp(left_region, seg_size)
        right_chunks = _split_and_ptp(right_region, seg_size)

        if not left_chunks or not right_chunks:
            aligned.append([s, e])
            continue

        l_max_idx, l_max_ptp = max(enumerate(left_chunks), key=lambda x: x[1])
        r_max_idx, r_max_ptp = max(enumerate(right_chunks), key=lambda x: x[1])

        if abs(e - s) < narrow_threshold:
            # 窄区间：选变化更大的一侧，用非对称偏移修正精确定位跳变点
            itv_width = abs(e - s)
            if l_max_ptp >= r_max_ptp:
                new_s, new_e = _offset_refine(left_region, left_win[0], l_max_idx, seg_size, itv_width)
            else:
                new_s, new_e = _offset_refine(right_region, right_win[0], r_max_idx, seg_size, itv_width)
            aligned.append([max(0, new_s), min(n - 1, new_e)])
        else:
            # 宽区间：左右分别精修
            new_start = left_win[0] + l_max_idx * seg_size
            new_end = right_win[0] + (r_max_idx + 1) * seg_size
            if new_start < new_end:
                aligned.append([new_start, min(n - 1, new_end)])
            else:
                aligned.append([s, e])

    return aligned


def _offset_refine(
    region: np.ndarray,
    win_start: int,
    max_idx: int,
    seg_size: int,
    interval_width: int = 0,
) -> tuple[int, int]:
    """窄区间偏移修正：在 ptp 最大段内找均值偏离最大点，用非对称窗口微调边界。"""
    n_segs = max(1, len(region) // seg_size)
    chunks = np.array_split(region, n_segs)
    if max_idx >= len(chunks):
        max_idx = len(chunks) - 1

    chunk = chunks[max_idx]
    chunk_len = len(chunk)
    if chunk_len == 0:
        return win_start + max_idx * seg_size, win_start + (max_idx + 1) * seg_size

    mean_val = np.mean(chunk)
    dist = np.abs(chunk - mean_val)
    idx_d = int(np.argmax(dist))

    # 非对称展开：区间宽度与段长度差异越大，偏移补偿越大
    kp = max(interval_width - chunk_len, 0) / 2
    cum = np.cumsum([0] + [len(c) for c in chunks])
    base = win_start + cum[max_idx] + idx_d
    half = seg_size // 2
    return round(base - half - kp), round(base + half + kp)


def _split_and_ptp(region: np.ndarray, seg_size: int) -> list[float]:
    """将 region 切成 seg_size 大小的段，返回每段的 peak-to-peak 值。"""
    if len(region) == 0 or seg_size <= 0:
        return []
    n_segs = max(1, len(region) // seg_size)
    return [float(np.max(chunk) - np.min(chunk)) for chunk in np.array_split(region, n_segs)]
