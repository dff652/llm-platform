"""
零值、负值、一值检测模块

包含零值、负值、一值检测相关的函数
"""

import pandas as pd
from .utils import timer_decorator


@timer_decorator 
def check_zero_values(data):
    """
    检测数据中零值
    
    Parameters
    ----
    data : pd.DataFrame
        输入的数据集
    
    Returns
    ----
    indices_df : pd.DataFrame
        布尔索引，标记每个数据点是否为零值
    """
    columns_to_check = data.columns
    result_df = pd.DataFrame(index=['zero_value_ratio'], columns=data.columns)
    indices_df = pd.DataFrame(index=data.index, columns=data.columns)
    for col in columns_to_check:
        zero_mask = data[col] == 0
        zero_ratio = zero_mask.sum() / len(data)
        result_df.loc['zero_value_ratio', col] = zero_ratio
        result_df.loc['zero_value_count', col] = zero_mask.sum()
        indices_df[col] = zero_mask

    return  indices_df


@timer_decorator
def check_one_values(data):
    """
    检测数据中的1值
    
    Parameters
    ----
    data : pd.DataFrame
        输入的数据集
        
    Returns
    ----
    indices_df : pd.DataFrame
        布尔索引，标记每个数据点是否为1值
    """
    columns_to_check = data.columns
    result_df = pd.DataFrame(index=['one_value_ratio'], columns=data.columns)
    indices_df = pd.DataFrame(index=data.index, columns=data.columns)
    for col in columns_to_check:
        one_mask = data[col] == 1
        one_ratio = one_mask.sum() / len(data)
        result_df.loc['one_value_ratio', col] = one_ratio
        result_df.loc['one_value_count', col] = one_mask.sum()
        indices_df[col] = one_mask

    return  indices_df


@timer_decorator
def check_negative_values(data):
    """
    检测数据中的负值
    
    Parameters
    ----
    data : pd.DataFrame
        输入的数据集
        
    Returns
    ----
    indices_df : pd.DataFrame
        布尔索引，标记每个数据点是否为负值
    """
    columns_to_check = data.columns
    result_df = pd.DataFrame(index=['negative_value_ratio'], columns=data.columns)
    indices_df = pd.DataFrame(index=data.index, columns=data.columns)
    for col in columns_to_check:
        negative_mask = data[col] < 0
        negative_ratio = negative_mask.sum() / len(data)
        result_df.loc['negative_value_ratio', col] = negative_ratio
        result_df.loc['negative_value_count', col] = negative_mask.sum()
        indices_df[col] = negative_mask

    return indices_df


def check_range(data: pd.DataFrame,
                max_value: float,
                min_value: float,
                ) -> pd.DataFrame:
    """
    检查数据量程，并标记超量程的数据
    
    Parameters
    ----
    data : pd.DataFrame
        输入的数据集
    max_value : float
        数据最大值
    min_value : float
        数据最小值
        
    Returns
    ----
    range_indices : pd.DataFrame
        布尔索引，标记每个数据点是否超量程
    """
    columns_to_check = data.columns
    range_indices = pd.DataFrame(index=data.index, columns=data.columns)
    
    for col in columns_to_check:
        range_mask = (data[col] > max_value) | (data[col] < min_value)
        range_indices[col] = range_mask

    return range_indices 