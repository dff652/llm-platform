"""
唯一值检测模块

包含唯一值检测相关的函数
"""

import pandas as pd
from .utils import timer_decorator
from .time_continuity import get_global_indices


@timer_decorator
def check_unique_values(data, keep='first'):
    """
    检测数据中的唯一值
    
    Parameters
    ----
    data : pd.DataFrame
        输入的数据集
    keep : str, optional
        保留重复值中的第一个或最后一个，默认为'first'
    
    Returns
    ----
    indices_df : pd.DataFrame
        布尔索引，标记每个数据点是否为唯一值
    """
    columns_to_check = data.columns
    result_df = pd.DataFrame(index=['unique_value_ratio'], columns=data.columns)
    indices_df = pd.DataFrame(index=data.index, columns=data.columns)
    for col in columns_to_check:
        unique_mask = ~data[col].duplicated(keep=keep)
        unique_ratio = unique_mask.sum() / len(data)
        result_df.loc['unique_value_ratio', col] = unique_ratio
        result_df.loc['unique_value_count', col] = unique_mask.sum()
        indices_df[col] = unique_mask

    return  indices_df


@timer_decorator
def check_duplicate_topk(data: pd.DataFrame, 
                         st_global: str = None,
                         et_global: str = None,
                         topk: int = 3,
                         ):
    """
    检查数据中的重复占比最高的前k个值
    
    Parameters
    ----
    data : pd.DataFrame
        输入的数据集
    st_global : str, optional
        页面选取的开始时间，默认为None
    et_global : str, optional
        页面选取的结束时间，默认为None
    topk : int, optional
        唯一值的数量，默认为3
        
    Returns
    ----
    df : pd.DataFrame
        包含前k个重复值的信息
    indices_df : pd.Series
        布尔索引，标记每个数据点是否为前k个重复值
    """
    if st_global is not None or et_global is not None:
        # 确保 st_global 是 pd.Timestamp 类型
        if not isinstance(st_global, pd.Timestamp):
            if isinstance(st_global, str):
                st_global = pd.to_datetime(st_global)
            else:
                st_global = pd.Timestamp(st_global)
        
        # 确保 et_global 是 pd.Timestamp 类型
        if not isinstance(et_global, pd.Timestamp):
            if isinstance(et_global, str):
                et_global = pd.to_datetime(et_global)
            else:
                et_global = pd.Timestamp(et_global)

        ts = 'ts'
        time_index = pd.DataFrame()
        time_index[ts] = data.index
        interval = (time_index[ts] - time_index[ts].shift(1))
        interval_seconds = interval.dt.total_seconds()
        discontinuity_threshold = interval_seconds.mode()[0]
        
        global_indices = get_global_indices(data, st_global, et_global, discontinuity_threshold)
        
        sum_count = global_indices.shape[0]
        
    else:
        sum_count = data.shape[0]

    columns_to_check = data.columns
    for col in columns_to_check:
        df_topk = data[col].value_counts().head(topk)
        topk_values = df_topk.index
        indices_df = data[col].isin(topk_values)
        print(f'indices_df.sum()={indices_df.sum()}')
        # Series 转 DataFrame
        df = pd.DataFrame(df_topk.items(), columns=['value', 'count'])
        # 计算 ratio 列
        df['ratio'] = df['count'] / sum_count

    return df, indices_df 