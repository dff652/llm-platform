"""
@File    :   base_detector.py
@Time    :   2024/11/12 
@Author  :   DouFengfeng
@Version :   1.0.0
@Contact :   ff.dou@cyber-insight.com
@License :   (C)Copyright 2019-2026, CyberInsight
@Desc    :   异常检测器基类，提供通用功能
@Update  :   DouFengfeng, 2024/11/12

"""

from abc import ABC, abstractmethod
import pandas as pd
import numpy as np
from typing import Optional, List, Dict, Any, Tuple

from .signal_processing import (
    get_fulldata, 
    adaptive_downsample, 
    calculate_sampling_rate,
    is_step_data, 
    is_noisy_data,
    dead_value_detection,
    get_true_indices
)
from .ensemble import create_outlier_mask


class BaseAnomalyDetector(ABC):
    """
    异常检测器基类
    
    提供所有异常检测算法通用的功能，包括：
    - 数据验证和预处理
    - 数据类型分析
    - 死值检测
    - 异常索引管理
    """
    
    def __init__(self, 
                 name: str,
                 insert_missing: bool = True,
                 detection_dead_value: bool = True,
                 detection_deviation: bool = False,
                 min_threshold: int = 500000,
                 **kwargs):
        """
        初始化基础异常检测器
        
        Parameters
        ----
        name : str
            检测器名称
        insert_missing : bool, optional
            是否插入缺失值，默认为True
        detection_dead_value : bool, optional
            是否进行死值检测，默认为True
        detection_deviation : bool, optional
            是否进行偏差检测，默认为False
        min_threshold : int, optional
            最小阈值，默认为500000
        **kwargs
            其他算法特定参数
        """
        self.name = name
        self.insert_missing = insert_missing
        self.detection_dead_value = detection_dead_value
        self.detection_deviation = detection_deviation
        self.min_threshold = min_threshold
        
        # 内部状态变量
        self._raw_data = None
        self._processed_data = None
        self._sampling_rate = None
        self._data_type = []
        self._global_indices = np.array([], dtype=int)
        self._local_indices = np.array([], dtype=int)
        
        # 存储算法特定参数
        for key, value in kwargs.items():
            setattr(self, key, value)
    
    def _validate_data(self, data: pd.DataFrame) -> None:
        """
        验证输入数据的有效性
        
        Parameters
        ----
        data : pd.DataFrame
            输入数据
            
        Raises
        ----
        ValueError
            当数据无效时
        """
        if data.empty:
            raise ValueError("Input data is empty")
        
        if not isinstance(data.index, pd.DatetimeIndex):
            try:
                data.index = pd.to_datetime(data.index)
            except Exception as e:
                raise ValueError(f"Index must be convertible to DatetimeIndex. "
                              f"Current index type: {type(data.index)}. Error: {e}")
    
    def _preprocess_data(self, data: pd.DataFrame, 
                        downsampler: str = 'm4',
                        sample_param: float = 0.1) -> pd.DataFrame:
        """
        数据预处理：插入缺失值、降采样等
        
        Parameters
        ----
        data : pd.DataFrame
            原始数据
        downsampler : str, optional
            降采样方法，默认为'm4'
        sample_param : float, optional
            采样参数，默认为0.1
            
        Returns
        ----
        pd.DataFrame
            预处理后的数据
        """
        raw_data = data.copy()
        column = raw_data.columns[0]
        
        # 插入缺失值
        if self.insert_missing:
            data = get_fulldata(raw_data, column)
        
        # 降采样
        downsampled_data, ts = adaptive_downsample(
            data[column], 
            downsampler=downsampler, 
            sample_param=sample_param,
            min_threshold=self.min_threshold
        )
        
        # 创建处理后的数据
        processed_data = pd.DataFrame()
        processed_data.index = ts
        processed_data[column] = downsampled_data
        
        self._raw_data = raw_data
        self._processed_data = processed_data
        
        return processed_data
    
    def _analyze_data_type(self, data: pd.DataFrame) -> None:
        """
        分析数据类型：是否为阶跃数据或噪声数据
        
        Parameters
        ----
        data : pd.DataFrame
            待分析的数据
        """
        column = data.columns[0]
        sampling_rate = calculate_sampling_rate(data[column])
        self._sampling_rate = sampling_rate
        
        step_type = is_step_data(data)
        noise_type = is_noisy_data(data[column], fs=sampling_rate)
        
        self._data_type = []
        if step_type:
            self._data_type.append("step")
        if noise_type:
            self._data_type.append("noise")
    
    def _detect_dead_values(self, global_indices: np.ndarray, 
                           dead_value_window: int = 72000,
                           dead_value_threshold: float = 0.7) -> np.ndarray:
        """
        死值检测
        
        Parameters
        ----
        global_indices : np.ndarray
            现有的全局异常索引
        dead_value_window : int, optional
            死值检测窗口大小，默认为72000
        dead_value_threshold : float, optional
            死值比例阈值，默认为0.7
            
        Returns
        ----
        np.ndarray
            更新后的全局异常索引
        """
        if not self.detection_dead_value:
            return global_indices
            
        _, dead_df, _ = dead_value_detection(self._processed_data, dead_value_window)
        dead_per = dead_df.sum() / len(dead_df)
        dead_per = dead_per.values[0]
        
        if dead_per < dead_value_threshold:
            natural_indices = get_true_indices(dead_df)
            global_list = global_indices.tolist()
            global_list.extend(natural_indices)
            global_indices = np.unique(global_list)
            
        return global_indices
    
    def _create_anomaly_mask(self, global_indices: np.ndarray) -> pd.Series:
        """
        创建异常掩码
        
        Parameters
        ----
        global_indices : np.ndarray
            全局异常索引
            
        Returns
        ----
        pd.Series
            异常掩码
        """
        if len(self._processed_data) == 0:
            return pd.Series(dtype=bool)
            
        column = self._processed_data.columns[0]
        return create_outlier_mask(self._processed_data[column], global_indices)
    
    def _process_results(self, global_indices: np.ndarray) -> pd.DataFrame:
        """
        处理最终结果，将异常标记应用到原始数据
        
        Parameters
        ----
        global_indices : np.ndarray
            全局异常索引
            
        Returns
        ----
        pd.DataFrame
            带有异常标记的原始数据
        """
        if len(global_indices) == 0:
            # 如果没有异常，返回全False的掩码
            column = self._raw_data.columns[0]
            self._raw_data[column] = False
            return self._raw_data
        
        # 创建异常掩码
        anomaly_mask = self._create_anomaly_mask(global_indices)
        
        # 将异常标记应用到原始数据
        column = self._raw_data.columns[0]
        # 避免链式赋值警告
        raw_data_copy = self._raw_data.copy()
        raw_data_copy[column] = False
        self._raw_data = raw_data_copy
        
        # 根据时间索引映射异常点
        for idx in global_indices:
            if idx < len(anomaly_mask):
                if anomaly_mask.iloc[idx]:
                    # 找到对应的时间点
                    if idx < len(self._processed_data):
                        time_point = self._processed_data.index[idx]
                        # 在原始数据中找到最接近的时间点
                        closest_idx = self._raw_data.index.get_indexer([time_point], method='nearest')[0]
                        if closest_idx >= 0:
                            column_name = self._raw_data.columns[0]
                            self._raw_data.loc[self._raw_data.index[closest_idx], column_name] = True
        
        return self._raw_data
    
    @abstractmethod
    def _detect_anomalies(self, data: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """
        核心异常检测逻辑（子类必须实现）
        
        Parameters
        ----
        data : pd.DataFrame
            输入数据
            
        Returns
        ----
        Tuple[np.ndarray, np.ndarray]
            (global_indices, local_indices) 全局和局部异常索引
        """
        pass
    
    def detect(self, data: pd.DataFrame, **kwargs) -> pd.DataFrame:
        """
        主要的异常检测方法
        
        Parameters
        ----
        data : pd.DataFrame
            输入数据
        **kwargs
            算法特定参数
            
        Returns
        ----
        pd.DataFrame
            带有异常标记的原始数据
        """
        # 数据验证
        self._validate_data(data)
        
        # 数据预处理
        processed_data = self._preprocess_data(data, **kwargs)
        
        # 数据类型分析
        self._analyze_data_type(data)
        
        # 核心异常检测
        global_indices, local_indices = self._detect_anomalies(processed_data)
        
        # 更新内部状态
        self._global_indices = global_indices
        self._local_indices = local_indices
        
        # 死值检测
        if self.detection_dead_value:
            self._global_indices = self._detect_dead_values(self._global_indices)
        
        # 处理最终结果
        return self._process_results(self._global_indices)
    
    def get_detection_info(self) -> Dict[str, Any]:
        """
        获取检测信息
        
        Returns
        ----
        Dict[str, Any]
            检测信息字典
        """
        return {
            'name': self.name,
            'data_type': self._data_type,
            'sampling_rate': self._sampling_rate,
            'global_indices_count': len(self._global_indices),
            'local_indices_count': len(self._local_indices),
            'raw_data_shape': self._raw_data.shape if self._raw_data is not None else None,
            'processed_data_shape': self._processed_data.shape if self._processed_data is not None else None
        }
    
    def reset(self) -> None:
        """
        重置检测器状态
        """
        self._raw_data = None
        self._processed_data = None
        self._sampling_rate = None
        self._data_type = []
        self._global_indices = np.array([], dtype=int)
        self._local_indices = np.array([], dtype=int)
