"""
check_outlier — 异常检测算法包

统一入口：每个算法模块提供 detect() 函数。

支持的算法：
- n_sigma: N 倍标准差 + 邻近合并
- iqr_outliers: IQR 四分位距 + 邻近合并
- ensemble: SG 滤波 + 多项式回归残差 + IQR (别名 piecewise_linear)
- isolation_forest: sklearn IsolationForest + 邻近合并 (别名 iforest)
- wavelet: 小波分解残差 + N-sigma
- stl_wavelet: STL 分解 + wavelet (原 global/m4_stl)
- adtk_hbos: HBOS + ADTK 漂移 + MeanShift + 死值 (原 jm)
"""

# ---- 高层 detect() 入口 ----
from .n_sigma import detect as n_sigma_detect
from .iqr_outliers import detect as iqr_outliers_detect
from .ensemble import detect as ensemble_detect
from .wavelet import detect as wavelet_detect
from .isolation_forest import detect as isolation_forest_detect
from .stl_wavelet import stl_wavelet_detect
from .adtk_hbos import detect as adtk_hbos_detect_func
from .adtk_hbos import adtk_hbos_detect  # 完整管道版本

# ---- 底层原语（向后兼容） ----
from .signal_processing import (
    ts_downsample, stl_decompose_cpu,
    check_time_continuity, get_fulldata, min_max_scaling, variance_filter,
    get_true_indices, dead_value_detection, is_step_data, is_noisy_data,
    adaptive_downsample, calculate_sampling_rate
)
from .ensemble import (
    replace_outliers_by_3sigma, create_outlier_mask, iqr_find_anomaly_indices,
    nsigma_find_anomaly_indices, piecewise_linear, standardized_find_anomaly_indices
)
from .wavelet import (
    reconstruct_residuals, split_continuous_outliers, range_split_outliers,
    exclude_indices, fit_and_replace_outliers
)
from .isolation_forest import detect_isolation_forest

__all__ = [
    # 高层入口
    'n_sigma_detect',
    'iqr_outliers_detect',
    'ensemble_detect',
    'wavelet_detect',
    'isolation_forest_detect',
    'stl_wavelet_detect',
    'adtk_hbos_detect_func',
    'adtk_hbos_detect',
    # 底层原语
    'ts_downsample', 'stl_decompose_cpu',
    'check_time_continuity', 'get_fulldata', 'min_max_scaling', 'variance_filter',
    'get_true_indices', 'dead_value_detection', 'is_step_data', 'is_noisy_data',
    'adaptive_downsample', 'calculate_sampling_rate',
    'replace_outliers_by_3sigma', 'create_outlier_mask', 'iqr_find_anomaly_indices',
    'nsigma_find_anomaly_indices', 'piecewise_linear', 'standardized_find_anomaly_indices',
    'reconstruct_residuals', 'split_continuous_outliers', 'range_split_outliers',
    'exclude_indices', 'fit_and_replace_outliers',
    'detect_isolation_forest',
]
