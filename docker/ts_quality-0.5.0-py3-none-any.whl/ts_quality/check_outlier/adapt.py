import numpy as np

def knpt(scores):
    """
    Detect knee point threshold on sorted scores using KneeLocator.

    Parameters
    ----
    scores : array-like
        Score sequence (will be sorted internally).

    Returns
    ----
    float
        Selected threshold at the knee point.
    """
    from kneed import KneeLocator
    sorted_scores = np.sort(scores)
    indices = np.arange(len(sorted_scores))
    kn = KneeLocator(indices, sorted_scores, curve='convex', direction='increasing')
    kne = kn.knee
    if kne:
        trh = sorted_scores[kne]
    else:
        trh = sorted_scores[np.argmax(sorted_scores[1:]/(sorted_scores[:-1]+0.001))]
    return trh

# ---------- Strategy: Threshold Selection ----------
class ThresholdSelector:
    """
    Base selector to choose a threshold from a score sequence.
    """
    def select(self, scores):
        """
        Parameters
        ----
        scores : array-like
            Score sequence.

        Returns
        ----
        float
            Selected threshold.
        """
        raise NotImplementedError

class FixedThreshold(ThresholdSelector):
    """
    Fixed threshold selector.
    """
    def __init__(self, value: float):
        self.value = float(value)
    def select(self, scores):
        return self.value

class KneePointThreshold(ThresholdSelector):
    """
    Knee point based adaptive threshold selector.
    """
    def select(self, scores):
        return float(knpt(np.asarray(scores)))

# ---------- Strategy: Segment continuous indices ----------
from typing import List, Tuple
import pandas as pd

class Segmenter:
    """
    Base segmenter to split consecutive indices into groups.
    """
    def split(self, indices: List[int]):
        """
        Parameters
        ----
        indices : list[int]
            Natural indices of anomalies.

        Returns
        ----
        list[np.ndarray]
            Groups of consecutive indices.
        """
        raise NotImplementedError

class ConsecutiveIndexSegmenter(Segmenter):
    """
    Segment consecutive indices with a maximum allowed gap.
    """
    def __init__(self, max_gap: int = 1):
        self.max_gap = int(max_gap)
    def split(self, indices):
        if indices is None or len(indices) == 0:
            return []
        # 确保输入是列表类型
        if isinstance(indices, np.ndarray):
            indices = indices.tolist()
        elif not isinstance(indices, list):
            indices = list(indices)
        
        # 确保所有元素都是整数
        try:
            indices = [int(x) for x in indices]
        except (ValueError, TypeError) as e:
            raise ValueError(f"All elements must be convertible to int: {e}")
        
        indices = np.asarray(sorted(indices), dtype=int)
        groups = []
        start = 0
        for i in range(1, len(indices)):
            if indices[i] - indices[i-1] > self.max_gap:
                groups.append(indices[start:i])
                start = i
        groups.append(indices[start:])
        return groups

# ---------- GroupingStrategy abstraction (extensible e.g., clustering) ----------
class GroupingStrategy:
    """
    Abstract grouping strategy that converts raw indices into groups.
    Default implementation is based on consecutive segmentation.
    """
    def group(self, data: pd.Series, indices: List[int]) -> List[np.ndarray]:
        raise NotImplementedError

class ConsecutiveGroupingStrategy(GroupingStrategy):
    """
    Group by consecutive indices using a Segmenter.
    """
    def __init__(self, segmenter: Segmenter):
        self.segmenter = segmenter
    def group(self, data: pd.Series, indices: List[int]) -> List[np.ndarray]:
        return self.segmenter.split(indices)

# ---------- GroupClassifier abstraction (range-based or ML-based) ----------
class GroupClassifier:
    """
    Abstract classifier that assigns groups to categories (e.g., global/local).
    """
    def classify(self, data: pd.Series, groups: List[np.ndarray]) -> Tuple[np.ndarray, np.ndarray]:
        raise NotImplementedError

class RangeRatioGroupClassifier(GroupClassifier):
    """
    Split anomaly groups into global/local by comparing local/global range ratio.
    """
    def __init__(self, range_selector: ThresholdSelector):
        self.range_selector = range_selector
    def classify(self, data: pd.Series, groups: List[np.ndarray]) -> Tuple[np.ndarray, np.ndarray]:
        if groups is None or len(groups) == 0:
            return np.array([], dtype=int), np.array([], dtype=int)
        arr = np.asarray(data)
        global_range = (np.max(np.abs(arr)) - np.min(np.abs(arr))) if len(arr) > 0 else 0.0
        if global_range == 0:
            merged = np.concatenate(groups) if len(groups) else np.array([], dtype=int)
            return np.array([], dtype=int), np.asarray(merged, dtype=int)
        ratios = []
        for g in groups:
            local = arr[g]
            local_range = np.max(np.abs(local)) - np.min(np.abs(local)) if len(local) > 0 else 0.0
            ratios.append(local_range / (global_range + 1e-12))
        thr = float(self.range_selector.select(ratios))
        global_indices: List[int] = []
        local_indices: List[int] = []
        for g, r in zip(groups, ratios):
            if r >= thr:
                global_indices.extend(g.tolist())
            else:
                local_indices.extend(g.tolist())
        return np.asarray(sorted(set(global_indices)), dtype=int), np.asarray(sorted(set(local_indices)), dtype=int)

# ---------- Utility: compose jump indices from multiple sources ----------
class CandidateIndicesComposer:
    """
    Generic composer to merge candidate anomaly indices from multiple sources
    (different detectors, scales, or transforms). Provides deduplication,
    sorting and optional local refinement.
    """
    def __init__(self, dedup: bool = True, sort: bool = True, window_refine: int = 0):
        self.dedup = dedup
        self.sort = sort
        self.window_refine = int(window_refine)
    def merge_sources(self, *indices_lists: List[int]) -> List[int]:
        merged = []
        for seq in indices_lists:
            if seq is None:
                continue
            # support numpy arrays, lists
            merged.extend(list(np.asarray(seq).tolist()))
        if self.dedup:
            merged = list(set(merged))
        if self.sort:
            merged.sort()
        return merged
    def refine(self, data: pd.Series, indices: List[int]) -> List[int]:
        if self.window_refine <= 0 or len(indices) == 0:
            return indices
        arr = np.asarray(data)
        refined = []
        half = self.window_refine
        n = len(arr)
        for idx in indices:
            s = max(0, idx - half)
            e = min(n, idx + half + 1)
            win = arr[s:e]
            if len(win) == 0:
                refined.append(idx)
                continue
            local_idx = int(np.argmax(np.abs(win - np.median(win))))
            refined.append(s + local_idx)
        refined = sorted(set(refined))
        return refined

# ---------- Backward-compatible helper (optional) ----------
# Provide a function-compatible wrapper for range splitting for legacy callers.
# Keep old name but now delegate to the classifier interface.
def range_split_outliers(data, groups, range_th=0.1):
    selector = FixedThreshold(range_th)
    classifier = RangeRatioGroupClassifier(selector)
    return classifier.classify(data, groups)
