"""
@File    :   stl_wavelet.py
@Time    :   2024/07/15 
@Author  :   DouFengfeng
@Version :   1.0.0
@Contact :   ff.dou@cyber-insight.com
@License :   (C)Copyright 2019-2026, CyberInsight
@Desc    :   时间序列异常检测（STL + Wavelet）
@Update  :   DouFengfeng, 2024/11/12

"""


import pandas as pd
import numpy as np
import warnings

# 修复相对导入问题 - 改为绝对导入
from .signal_processing import ts_downsample, stl_decompose_cpu, check_time_continuity, \
    get_fulldata, min_max_scaling,variance_filter,get_true_indices,dead_value_detection, is_step_data, is_noisy_data, \
    adaptive_downsample, calculate_sampling_rate
from .ensemble import replace_outliers_by_3sigma, create_outlier_mask, iqr_find_anomaly_indices, \
    nsigma_find_anomaly_indices, piecewise_linear, standardized_find_anomaly_indices
from .wavelet import reconstruct_residuals, split_continuous_outliers, range_split_outliers,exclude_indices,\
    fit_and_replace_outliers,safe_split_continuous_outliers
from .isolation_forest import detect_isolation_forest
from .base_detector import BaseAnomalyDetector
from scipy import signal
from scipy.signal import savgol_filter
from .adapt import ConsecutiveIndexSegmenter, RangeRatioGroupClassifier, FixedThreshold


class STLWaveletDetector(BaseAnomalyDetector):
    """
    STL分解和小波变换的异常检测器
    
    该类封装了基于STL分解和小波变换的时间序列异常检测功能，
    包括数据预处理、异常检测、死值检测等。
    """
    
    def __init__(self, 
                 downsampler: str = 'm4',
                 sample_param: float = 0.1,
                 method: str = 'wavelet',
                 threshold: float = 8,
                 num_points: int = 1200,
                 range_threshold: float = 0.2,
                 insert_missing: bool = True,
                 decompose: bool = True,
                 min_threshold: int = 200000,
                 detection_dead_value: bool = True,
                 detection_deviation: bool = False,  # 默认关闭偏差检测以提高性能
                 fitted: bool = True):
        """
        初始化STLWaveletDetector
        
        Parameters
        ----
        downsampler : str, optional
            降采样方法，支持'm4', 'minmax', 'none'或None，为None或'none'时不降采样，默认为'm4'
        sample_param : float, optional
            采样参数，默认为0.1
            - 0到1之间按比例降采样(例如0.1表示保留10%)
            - 大于1时自动使用min_threshold作为固定降采样数量
        method : str, optional
            异常检测方法，默认为'wavelet'
        threshold : float, optional
            异常检测阈值，默认为8
        num_points : int, optional
            在一个窗口中合并的点数，默认为1200
        range_threshold : float, optional
            范围划分阈值，默认为0.2
        insert_missing : bool, optional
            是否插入缺失值，默认为True
        decompose : bool, optional
            是否进行STL分解，默认为True
        min_threshold : int, optional
            最小阈值，默认为200000
            1. 当数据量小于此值时不进行降采样
            2. 当sample_param > 1时，作为固定降采样数量
        detection_dead_value : bool, optional
            是否进行死值检测，默认为True
        detection_deviation : bool, optional
            是否进行偏差检测，默认为True
        fitted : bool, optional
            是否进行拟合，默认为True
        """
        super().__init__(
            name="STLWavelet",
            insert_missing=insert_missing,
            detection_dead_value=detection_dead_value,
            detection_deviation=detection_deviation,
            min_threshold=min_threshold,
            downsampler=downsampler,
            sample_param=sample_param,
            method=method,
            threshold=threshold,
            num_points=num_points,
            range_threshold=range_threshold,
            decompose=decompose,
            fitted=fitted
        )
        # default post-processing strategies
        self.index_segmenter = ConsecutiveIndexSegmenter()
        self.group_classifier = RangeRatioGroupClassifier(FixedThreshold(self.range_threshold))
    
    def _sigma_filtered_and_anomaly_detection(self, data, method=None, th=None, N=None):
        """
        使用sigma过滤和异常检测的组合方法
        
        Parameters
        ----
        data : pd.Series
            输入的时间序列数据
        method : str, optional
            异常检测方法，默认使用实例的method属性
        th : float, optional
            异常检测阈值，默认使用实例的threshold属性
        N : float, optional
            合并长度参数，默认使用实例的num_points属性
            
        Returns
        ----
        outlier_mask : array-like
            异常值掩码
        anomaly_indices : array-like
            异常点索引
        """
        if method is None:
            method = self.method
        if th is None:
            th = self.threshold
        if N is None:
            N = self.num_points
            
        if data.empty:
            print("Received empty data for processing.")
            return None, None, None, None
            
        data_length = len(data)
        merge_len = N
        
        if method == 'piecewise_linear':
            window_length = min(601, data_length if data_length % 2 == 1 else data_length - 1)
            polyorder = min(3, window_length - 1)
            pre_data = savgol_filter(data.values.ravel(), window_length=window_length,
                                     polyorder=polyorder)
            reconstruct_data, residuals = piecewise_linear(pre_data)
            if reconstruct_data is None or residuals is None:
                print("回归后结果为空，返回对应的mask全为0。")
                return np.zeros(data.shape[0]), [], np.zeros(data.shape[0]), np.zeros(data.shape[0])
            anomaly_indices = iqr_find_anomaly_indices(residuals, th, merge_len)
        elif method == 'wavelet':
            min_max_data = np.array(min_max_scaling(data.values.ravel()), dtype=float, copy=True)
            reconstruct_data = reconstruct_residuals(min_max_data, wavelet='db1', level=3)
            anomaly_indices = nsigma_find_anomaly_indices(reconstruct_data, th, merge_len)
            pre_data = None
        elif method == 'standardized':
            detrended_data = signal.detrend(data.values.ravel(), type='linear')
            anomaly_indices = standardized_find_anomaly_indices(detrended_data, th, merge_len)
            reconstruct_data = None
            pre_data = None
        elif method == 'iforest':
            min_max_data = min_max_scaling(data.values.ravel())
            window_length = min(61, data_length if data_length % 2 == 1 else data_length - 1)
            polyorder = min(1, window_length - 1)
            pre_data = savgol_filter(min_max_data, window_length=window_length, polyorder=polyorder)
            reconstruct_data = reconstruct_residuals(pre_data.ravel(), wavelet='db1', level=3)
            anomaly_indices = detect_isolation_forest(data, outlier_ratio=th, N=merge_len)
            reconstruct_data = None
            pre_data = None
        else:
            raise ValueError(f"Unsupported method: {method}")
            
        outlier_mask = create_outlier_mask(data, anomaly_indices)
        print(f'---***---异常点数:{len(anomaly_indices)},数据长度:{len(data)},合并长度:{merge_len},阈值:{th} ---***---')
        return outlier_mask, anomaly_indices
    
    def _detect_anomalies_with_stl(self, downsampled_data: np.ndarray) -> tuple:
        """
        使用STL分解进行异常检测
        
        Parameters
        ----
        downsampled_data : np.ndarray
            降采样后的数据
            
        Returns
        ----
        tuple
            (global_indices, local_indices) 全局和局部异常索引
        """
        if len(downsampled_data) == 0:
            raise ValueError("downsampled_data is empty!")
        if np.any(pd.isnull(downsampled_data)):
            raise ValueError("downsampled_data contains NaN!")
        if not np.issubdtype(np.array(downsampled_data).dtype, np.floating):
            downsampled_data = np.array(downsampled_data, dtype=float)
        
        # STL分解
        df_trend, df_seasonal, df_resid = stl_decompose_cpu(downsampled_data, period=60)
        
        # 趋势分量异常检测
        trend_outlier_mask, trend_indices = self._sigma_filtered_and_anomaly_detection(
            df_trend, self.method, self.threshold, self.num_points)
        
        # 残差分量异常检测
        resid_outlier_mask, resid_indices = self._sigma_filtered_and_anomaly_detection(
            df_resid, self.method, self.threshold, self.num_points)
        
        # 合并异常索引
        # 确保 trend_indices 和 resid_indices 是列表类型
        if isinstance(trend_indices, np.ndarray):
            trend_indices_list = trend_indices.astype(int).tolist()
        else:
            trend_indices_list = list(trend_indices)
            
        if isinstance(resid_indices, np.ndarray):
            resid_indices_list = resid_indices.astype(int).tolist()
        else:
            resid_indices_list = list(resid_indices)
            
        combined_list = trend_indices_list + resid_indices_list
        unique_array = np.unique(combined_list)
        
        # 分割连续异常与范围划分（策略）
        # 确保 unique_array 是列表类型
        if isinstance(unique_array, np.ndarray):
            unique_array_list = unique_array.tolist()
        else:
            unique_array_list = list(unique_array)
        index_groups = self.index_segmenter.split(unique_array_list)
        # 使用基于固定阈值的范围划分（可在构造时替换为自适应）
        series = self._processed_data[self._processed_data.columns[0]]
        global_indices, local_indices = self.group_classifier.classify(series, index_groups)
        
        return global_indices, local_indices
    
    def _detect_anomalies_without_stl(self) -> tuple:
        """
        不使用STL分解的异常检测
        
        Returns
        ----
        tuple
            (global_indices, local_indices) 全局和局部异常索引
        """
        outlier_mask, anomaly_indices = self._sigma_filtered_and_anomaly_detection(
            self._processed_data, self.method, self.threshold, self.num_points)
        
        # 确保 anomaly_indices 是列表类型
        if isinstance(anomaly_indices, np.ndarray):
            anomaly_indices_list = anomaly_indices.tolist()
        else:
            anomaly_indices_list = list(anomaly_indices)
        index_groups = self.index_segmenter.split(anomaly_indices_list)
        series = self._processed_data[self._processed_data.columns[0]]
        global_indices, local_indices = self.group_classifier.classify(series, index_groups)
        
        return global_indices, local_indices
    
    def _detect_deviations(self, global_indices: np.ndarray) -> None:
        """
        偏差检测和拟合
        
        Parameters
        ----
        global_indices : np.ndarray
            全局异常索引
        """
        if not self.detection_deviation:
            return
            
        if self.fitted:
            column = self._processed_data.columns[0]
            data_arr = self._processed_data[column].values
            exclude_anomaly_idx = exclude_indices(data_arr, global_indices)
            data_fitted = fit_and_replace_outliers(data_arr, exclude_anomaly_idx, 2)
            
            # 确保 data_fitted 的长度与 DataFrame 匹配
            if len(data_fitted) != len(self._processed_data):
                print(f"警告: data_fitted 长度 ({len(data_fitted)}) 与 DataFrame 长度 ({len(self._processed_data)}) 不匹配，跳过拟合")
            else:
                # 使用 copy() 避免链式赋值警告
                processed_data_copy = self._processed_data.copy()
                processed_data_copy.loc[:, column] = data_fitted
                self._processed_data = processed_data_copy
        
        # 创建异常掩码
        global_mask = create_outlier_mask(self._processed_data, global_indices)
        # 避免链式赋值警告
        processed_data_copy = self._processed_data.copy()
        processed_data_copy['global_mask'] = global_mask
        self._processed_data = processed_data_copy
        
        # 方差过滤
        outlier_masks = [self._processed_data]
        combined_data = pd.concat(outlier_masks)
        combined_data = variance_filter(combined_data, 'global_mask', 'mean', 0.5)
        self._processed_data = combined_data.copy()
    
    def _detect_anomalies(self, data: pd.DataFrame) -> tuple:
        """
        核心异常检测逻辑（实现基类抽象方法）
        
        Parameters
        ----
        data : pd.DataFrame
            输入数据
            
        Returns
        ----
        tuple
            (global_indices, local_indices) 全局和局部异常索引
        """
        # 根据数据类型选择检测策略
        if "step" not in self._data_type and "noise" not in self._data_type:
            if self.decompose:
                # 使用STL分解
                global_indices, local_indices = self._detect_anomalies_with_stl(data[data.columns[0]])
            else:
                # 不使用STL分解
                global_indices, local_indices = self._detect_anomalies_without_stl()
            
            # 只在需要时进行偏差检测，避免重复计算
            if self.detection_deviation and len(global_indices) > 0:
                self._detect_deviations(global_indices)
            
            return global_indices, local_indices
        else:
            # 对于阶跃或噪声数据，返回空索引
            return np.array([], dtype=int), np.array([], dtype=int)
    
    def detect(self, data: pd.DataFrame, **kwargs) -> pd.DataFrame:
        """
        主要的异常检测方法
        
        Parameters
        ----
        data : pd.DataFrame
            输入数据
        **kwargs
            算法特定参数
            
        Returns
        ----
        pd.DataFrame
            带有异常标记的原始数据
        """
        # 抑制链式赋值警告
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", message=".*ChainedAssignmentError.*", category=FutureWarning)
            
            # 调用基类的detect方法（偏差检测已在_detect_anomalies中处理）
            result = super().detect(data, **kwargs)
        
        return result


# 为了保持向后兼容性，保留原有的函数接口
def sigma_filtered_and_anomaly_detection(data, method='piecewise_linear', th=1.5, N=0.01):
    """
    使用sigma过滤和异常检测的组合方法
    
    Parameters
    ----
    data : pd.Series
        输入的时间序列数据
    method : str, optional
        异常检测方法，默认为'piecewise_linear'
        - 'piecewise_linear': 分段线性回归
        - 'wavelet': 小波分解
        - 'standardized': 标准化方法
        - 'iforest': 孤立森林
    th : float, optional
        异常检测阈值，默认为1.5
    N : float, optional
        合并长度参数，默认为0.01
        
    Returns
    ----
    outlier_mask : array-like
        异常值掩码
    anomaly_indices : array-like
        异常点索引
    """
    detector = STLWaveletDetector(method=method, threshold=th, num_points=N)
    return detector._sigma_filtered_and_anomaly_detection(data, method, th, N)


def filter_data(data, mask='outlier_mask', threshold=2):
    """
    根据掩码过滤数据
    
    Parameters
    ----
    data : pd.DataFrame
        输入的数据
    mask : str, optional
        掩码列名，默认为'outlier_mask'
    threshold : int, optional
        阈值，默认为2
        
    Returns
    ----
    target_data : pd.DataFrame
        过滤后的数据
    """
    combine_masks = data.copy()
    combine_masks['label'] = combine_masks[mask].apply(lambda x: 1 if x >= threshold else 0)
    combine_masks['Group'] = (combine_masks['label'] != combine_masks['label'].shift()).cumsum()
    label_data = combine_masks[combine_masks['label'] == 1]
    grouped = label_data.groupby('Group')
    target_data = pd.DataFrame(columns=['variable', 'start_time', 'end_time'])
    for name, group in grouped:
        start_time = group.index.min()
        end_time = group.index.max()
        sensor = label_data.columns[0]
        target_data = pd.concat([target_data, pd.DataFrame({
            'variable': [sensor],
            'start_time': [start_time],
            'end_time': [end_time],
            'mask': [mask],
        })], ignore_index=True)
    return target_data


def stl_wavelet_detect(data: pd.DataFrame,
              downsampler: str = 'm4',
              sample_param: float = 0.1,
              method: str = 'wavelet',
              threshold: float = 8,
              num_points: int = 1200,
              range_threshold: float = 0.2,
              insert_missing=True,
              decompose: bool = True,
              min_threshold: int = 200000):
    """
    使用STL分解和异常检测处理时间序列数据
    
    Parameters
    ----
    data : pd.DataFrame
        输入数据
    downsampler : str, optional
        降采样方法，支持'm4', 'minmax', 'none'或None，为None或'none'时不降采样，默认为'm4'
    sample_param : float, optional
        采样参数，默认为0.1
        - 0到1之间按比例降采样(例如0.1表示保留10%)
        - 大于1时自动使用min_threshold作为固定降采样数量
    method : str, optional
        异常检测方法，默认为'wavelet'
    threshold : float, optional
        异常检测阈值，默认为8
    num_points : int, optional
        在一个窗口中合并的点数，默认为1200
    range_threshold : float, optional
        范围划分阈值，默认为0.2
    insert_missing : bool, optional
        是否插入缺失值，默认为True
    decompose : bool, optional
        是否进行STL分解，默认为True
    min_threshold : int, optional
        最小阈值，默认为200000
        1. 当数据量小于此值时不进行降采样
        2. 当sample_param > 1时，作为固定降采样数量
        
    Returns
    ----
    raw_data : pd.DataFrame
        带有异常标记的原始数据
    """
    # 使用优化的检测器，默认关闭偏差检测以提高性能
    detector = STLWaveletDetector(
        downsampler=downsampler,
        sample_param=sample_param,
        method=method,
        threshold=threshold,
        num_points=num_points,
        range_threshold=range_threshold,
        insert_missing=insert_missing,
        decompose=decompose,
        min_threshold=min_threshold,
        detection_deviation=False  # 默认关闭偏差检测以提高性能
    )
    return detector.detect(data)


