"""
向后兼容模块 - 已迁移到 adtk_hbos.py

请使用 from .adtk_hbos import detect, adtk_hbos_detect
"""
import warnings

warnings.warn(
    "jm_detect 已重命名为 adtk_hbos，请更新导入路径",
    DeprecationWarning,
    stacklevel=2,
)

from .adtk_hbos import (  # noqa: F401
    detect,
    adtk_hbos_detect,
    MeanShiftDetect,
    AnomalyBordersDetector,
    process_data,
)
