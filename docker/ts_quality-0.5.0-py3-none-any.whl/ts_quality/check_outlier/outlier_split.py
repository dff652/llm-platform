"""Outlier segment splitting utilities (threshold-based and cluster-based)."""

import numpy as np


def extract_outlier_features(data, outliers):
    """Extract statistical features for each anomaly segment.

    Returns an (N, 2) array with [mean_ratio, range_ratio] per segment.
    """
    features = []
    if hasattr(data, 'values'):
        data_array = data.iloc[:, 0].values if data.ndim > 1 and data.shape[1] > 0 else np.array(data).ravel()
    else:
        data_array = np.array(data).ravel()

    global_mean = np.mean(data_array)
    global_range = np.max(data_array) - np.min(data_array)

    for seg in outliers:
        if len(seg) == 0:
            continue
        local_data = data_array[seg]
        mean_val = np.mean(local_data)
        range_val = np.max(local_data) - np.min(local_data)
        mean_ratio = mean_val / global_mean if global_mean != 0 else 0
        range_ratio = range_val / global_range if global_range != 0 else 0
        features.append([mean_ratio, range_ratio])
    return np.array(features) if features else np.empty((0, 2))


def cluster_based_outlier_split(data, outliers, n_clusters=2, method='kmeans',
                                random_state=42):
    """Split outliers into global/local via clustering."""
    from .wavelet import range_split_outliers

    if len(outliers) < 2:
        if len(outliers) == 1:
            return np.array(outliers[0]), np.array([])
        return np.array([]), np.array([])

    try:
        features = extract_outlier_features(data, outliers)
        if features.shape[0] < n_clusters:
            return range_split_outliers(data, outliers, range_th=0.1)

        from sklearn.preprocessing import StandardScaler
        features_scaled = StandardScaler().fit_transform(features)

        if method == 'kmeans':
            from sklearn.cluster import KMeans
            clusterer = KMeans(n_clusters=n_clusters, random_state=random_state, n_init=10)
        elif method == 'dbscan':
            from sklearn.cluster import DBSCAN
            from sklearn.neighbors import NearestNeighbors
            nbrs = NearestNeighbors(n_neighbors=min(3, len(features_scaled))).fit(features_scaled)
            distances, _ = nbrs.kneighbors(features_scaled)
            eps = np.percentile(distances[:, -1], 75)
            clusterer = DBSCAN(eps=eps, min_samples=1)
        elif method == 'hierarchical':
            from sklearn.cluster import AgglomerativeClustering
            clusterer = AgglomerativeClustering(n_clusters=n_clusters)
        else:
            raise ValueError(f"Unsupported clustering method: {method}")

        labels = clusterer.fit_predict(features_scaled)
        local_outliers, global_outliers = [], []
        for outlier_seg, lbl in zip(outliers, labels):
            if lbl == 0 or lbl == -1:
                global_outliers.extend(outlier_seg)
            else:
                local_outliers.extend(outlier_seg)
        return np.array(global_outliers), np.array(local_outliers)
    except Exception:
        return range_split_outliers(data, outliers, range_th=0.1)


def adaptive_outlier_split(data, outliers, method='auto', **kwargs):
    """Auto-select outlier split method."""
    from .wavelet import range_split_outliers

    if method == 'auto':
        if len(outliers) < 3:
            method = 'threshold'
        else:
            features = extract_outlier_features(data, outliers)
            method = 'cluster' if features.shape[0] >= 3 else 'threshold'

    if method == 'threshold':
        return range_split_outliers(data, outliers, kwargs.get('range_th', 0.1))
    return cluster_based_outlier_split(
        data, outliers,
        n_clusters=kwargs.get('n_clusters', 2),
        method=kwargs.get('cluster_method', 'kmeans'),
        random_state=kwargs.get('random_state', 42),
    )
