"""
Wavelet 异常检测

提供底层原语和高层 detect() 入口：
- detect(): min-max 归一化 → 小波残差 → N-sigma 检测
- reconstruct_residuals(): 底层小波分解重构残差
"""
import numpy as np
from numpy.polynomial.polynomial import Polynomial
import pandas as pd
import pywt


def detect(data, threshold=5, merge_ratio=0.01, wavelet='db1', level=3):
    """
    Wavelet 异常检测：小波分解残差 + N-sigma 检测。

    Parameters
    ----------
    data : pd.DataFrame or pd.Series
        输入数据，单列
    threshold : float
        N-sigma 阈值，默认 5
    merge_ratio : float
        合并距离占数据长度比例，默认 0.01
    wavelet : str
        小波族名称，默认 'db1'
    level : int
        分解层数，默认 3

    Returns
    -------
    np.ndarray[int]
        异常点的自然索引数组，已去重排序
    """
    from .ensemble import nsigma_find_anomaly_indices
    from .signal_processing import min_max_scaling

    if isinstance(data, pd.DataFrame):
        values = data.iloc[:, 0].values.ravel()
    elif isinstance(data, pd.Series):
        values = data.values.ravel()
    else:
        values = np.asarray(data).ravel()

    data_length = len(values)
    merge_len = int(merge_ratio * data_length) if merge_ratio < 1 else int(merge_ratio)

    scaled = np.array(min_max_scaling(values), dtype=float, copy=True)  # pywt 需要可写数组
    residuals = reconstruct_residuals(scaled, wavelet=wavelet, level=level)
    return nsigma_find_anomaly_indices(residuals, th=threshold, N=merge_len)


def _safe_wavedec(data, wavelet='db1', level=3):
    """pywt.wavedec 的安全替代，避免 read-only buffer 问题。"""
    a = np.array(data, dtype=float, copy=True)
    coeffs = []
    for _ in range(level):
        a, d = pywt.dwt(a, wavelet)
        a = np.array(a, copy=True)  # 确保每层结果可写
        d = np.array(d, copy=True)
        coeffs.append(d)
    coeffs.append(a)
    coeffs.reverse()  # [cA_n, cD_n, ..., cD_1]
    return coeffs


def reconstruct_residuals(data, wavelet='db1', level=3):
    """
    使用小波分解的细节系数重构信号残差。

    参数:
    time_series_data -- 时间序列数据
    wavelet -- 小波名称，默认为 'db4'
    level -- 分解层数，默认为 3

    返回:
    reconstructed_residuals -- 仅使用细节系数重构的残差信号
    """
    # pywt 1.8 + Python 3.13 存在 read-only buffer 兼容性问题
    # wavedec 内部 dwt 返回的系数可能是 read-only，手动逐层分解绕过
    data = np.array(data, dtype=float, copy=True)
    coeffs = _safe_wavedec(data, wavelet, level=level)

    # 提取细节系数
    cA, *cD = coeffs
    # 仅使用细节系数重构残差信号，需要构建一个包含所有细节系数的列表
    reconstruct_data = pywt.waverec([None] + cD, wavelet)

    # waverec 可能因填充返回比输入多 1 个样本，截断到原始长度
    if len(reconstruct_data) > len(data):
        reconstruct_data = reconstruct_data[:len(data)]

    return reconstruct_data


# def split_continuous_outliers(outlier_indices, min_size=1):
#     # 类型和空值检查，防止 TypeError
#     if len(outlier_indices) == 0:
#         return []
#     # 保证所有元素为 int
#     outlier_indices = [int(i) for i in outlier_indices if isinstance(i, (int, np.integer, float))]
#     if not outlier_indices:
#         return []
#     split_indices = []
#     current_split = []
#     for i in range(len(outlier_indices)):
#         if not current_split or outlier_indices[i] == current_split[-1] + 1:
#             current_split.append(outlier_indices[i])
#         else:
#             if len(current_split) >= min_size:
#                 split_indices.append(current_split)
#             current_split = [outlier_indices[i]]
#     if len(current_split) >= min_size:
#         split_indices.append(current_split)
#     return split_indices


def split_continuous_outliers(indices, min_size=1):
    """
    安全分段连续异常索引（仅保留连续且长度>=min_size的分段）

    参数：
        indices: 可迭代对象，异常点下标
        min_size: 最小连续长度

    返回：
        List[List[int]]，每组为一段连续异常下标
    """
    # 1. 预处理：强制转int、去掉bool/None/NaN等脏数据
    cleaned = []
    for i in indices if indices is not None else []:
        if isinstance(i, (int, np.integer)) and not isinstance(i, bool):
            cleaned.append(int(i))
        # 支持 float 但要是整数值
        elif isinstance(i, float) and not np.isnan(i) and i == int(i):
            cleaned.append(int(i))
        # 其它类型自动跳过

    if not cleaned:
        return []

    # 2. 排序去重，保证连续性
    cleaned = sorted(set(cleaned))

    # 3. 分段
    splits = []
    current = [cleaned[0]]
    for prev, curr in zip(cleaned, cleaned[1:]):
        if curr == prev + 1:
            current.append(curr)
        else:
            if len(current) >= min_size:
                splits.append(current)
            current = [curr]
    # 结尾处理
    if len(current) >= min_size:
        splits.append(current)
    return splits



def safe_split_continuous_outliers(indices, min_size=1):
    """
    安全分段连续异常索引，防止 Cython/C 层段错误
    
    Parameters
    ----
    indices : array-like
        异常点索引
    min_size : int, optional
        最小连续长度，默认为1
        
    Returns
    ----
    list
        分段后的连续异常索引列表
    """
    # 彻底过滤所有非 int/float 类型，防止 Cython/C 层段错误
    if indices is None:
        return []
    
    filtered_indices = []
    for i in indices:
        if isinstance(i, (int, np.integer)) and not isinstance(i, bool):
            filtered_indices.append(int(i))
        elif isinstance(i, float) and not np.isnan(i) and i == int(i):
            filtered_indices.append(int(i))
    
    if not filtered_indices:
        return []
    
    return split_continuous_outliers(filtered_indices, min_size)


def range_split_outliers(data, outliers, range_th=0.1):
    # 复制数据以避免修改原始数据
    global_data = np.copy(data)

    # 计算全局范围
    global_range = np.max(np.abs(global_data)) - np.min(np.abs(global_data))
    local_outliers = []
    global_outliers = []

    for outlier in outliers:
        # 提取局部数据
        local_data = global_data[outlier]
        # 计算局部范围
        local_range = np.max(np.abs(local_data)) - np.min(np.abs(local_data))

        # 计算极差比
        range_ratio = local_range / global_range

        # 根据极差比判断是全局异常还是局部异常
        if range_ratio >= range_th:
            global_outliers.extend(outlier)
        # elif (range_th - 0.05) < range_ratio < range_th:
        #     local_outliers.extend(outlier)
        else:
            local_outliers.extend(outlier)

    # 将列表转换为numpy数组并返回
    return np.array(global_outliers), np.array(local_outliers)


def cv_sort_local_outlier(signal, outliers, th=0.5):
    cv_values = []  # 存储变异系数的列表
    cv_indices = []  # 存储对应下标的列表

    for outlier in outliers:
        local_part = signal[outlier]

        if len(local_part) > 1:
            mean_part = np.mean(local_part)
            if mean_part == 0:
                cv_part = np.std(local_part)
            else:
                cv_part = np.std(local_part) / mean_part
        else:
            cv_part = 0

        cv_values.append(cv_part)
        cv_indices.append(outlier)

    # 根据变异系数排序
    sorted_indices_and_values = sorted(zip(cv_values, cv_indices), reverse=True)
    sorted_cv_values, sorted_cv_indices = zip(*sorted_indices_and_values)

    # 选择异常值的数量
    num_to_select = max(1, int(len(sorted_cv_values) * (1 - th)))
    selected_indices_and_values = sorted_indices_and_values[:num_to_select]
    selected_cv_values, selected_cv_indices = zip(*selected_indices_and_values)

    # 合并并排序选定的异常值索引
    cv_extend_sorted = sorted(list(set([item for idx in selected_cv_indices for item in idx])))
    # print("排序后的变异系数：",selected_cv_values)
    return list(selected_cv_values), cv_extend_sorted


def refine_local_outliers(signal, outliers):
    refined_outliers = []

    for outlier in outliers:
        start_idx = max(outlier[0] - len(outlier), 0)
        end_idx = min(outlier[-1] + len(outlier), len(signal))

        right_parts = signal[start_idx:outlier[0]]
        left_parts = signal[outlier[-1]:end_idx]
        local_parts = signal[outlier]

        # 检查数组长度是否大于1
        if len(right_parts) > 1:
            right_std_dev = np.std(right_parts)
        else:
            right_std_dev = 0  # 或者一个默认值

        if len(left_parts) > 1:
            left_std_dev = np.std(left_parts)
        else:
            left_std_dev = 0  # 或者一个默认值

        if len(local_parts) > 1:
            local_std_dev = np.std(local_parts)
        else:
            local_std_dev = 0  # 或者一个默认值
        # 确定合并方向
        if len(local_parts) == 1:
            combined_parts = np.concatenate([left_parts, local_parts, right_parts])
            combined_start_idx = start_idx
            combined_end_idx = end_idx
        elif not np.isnan(left_std_dev) and (np.isnan(right_std_dev) or left_std_dev > right_std_dev):
            combined_parts = np.concatenate([left_parts, local_parts])
            combined_start_idx = start_idx
            combined_end_idx = end_idx
        elif not np.isnan(right_std_dev):
            combined_parts = np.concatenate([local_parts, right_parts])
            combined_start_idx = start_idx
            combined_end_idx = end_idx
        else:
            combined_parts = local_parts
            combined_start_idx = outlier[0]
            combined_end_idx = outlier[-1]
        # 打印combined_parts的数据长度
        # print(f"Length of combined_parts: {len(combined_parts)}")

        # 以数据长度为窗口，滑窗计算方差
        window_size = len(local_parts)
        max_std = 0
        max_outlier_segment = []

        # 确保滑动窗口的索引是基于原始信号的索引
        for i in range(len(combined_parts) - window_size + 1):
            window = combined_parts[i:i + window_size]
            if len(window) > 1:
                window_std = np.std(window)
                if window_std > max_std:
                    max_std = window_std
                    max_outlier_segment = list(range(combined_start_idx + i, combined_start_idx + i + window_size))

        if max_outlier_segment:
            refined_outliers.extend(max_outlier_segment)
    return np.array(refined_outliers)


def combine_local_outliers(signal, outliers):
    refined_outliers = []

    for outlier in outliers:
        # 确定局部区域的起始和结束索引
        start_idx = max(outlier[0] - len(outlier), 0)
        end_idx = min(outlier[-1] + len(outlier), len(signal))
        print('起始', start_idx, end_idx)

        # 提取左右和局部部分
        right_parts = signal[start_idx:outlier[0]]
        left_parts = signal[outlier[-1]:end_idx]
        local_parts = signal[outlier]

        # 计算标准差
        right_std_dev = np.std(right_parts) if len(right_parts) > 1 else 0
        left_std_dev = np.std(left_parts) if len(left_parts) > 1 else 0
        local_std_dev = np.std(local_parts) if len(local_parts) > 1 else 0

        # 向左扩展
        extend_count_left = 0
        prev_left_std_dev = left_std_dev  # 初始化前一次的标准差
        while start_idx > 0 and extend_count_left < 10:
            start_idx = max(start_idx - len(local_parts), 0)
            left_parts = signal[start_idx:outlier[0]]
            left_std_dev = np.std(left_parts) if len(left_parts) > 1 else 0
            if left_std_dev > prev_left_std_dev:
                prev_left_std_dev = left_std_dev
                extend_count_left += 1
                print('combined-left', start_idx)
            else:
                break

        # 向右扩展
        extend_count_right = 0
        prev_right_std_dev = right_std_dev  # 初始化前一次的标准差
        while end_idx < len(signal) and extend_count_right < 10:
            end_idx = min(end_idx + len(local_parts), len(signal))
            right_parts = signal[outlier[-1]:end_idx]
            right_std_dev = np.std(right_parts) if len(right_parts) > 1 else 0
            if right_std_dev > prev_right_std_dev:
                prev_right_std_dev = right_std_dev
                extend_count_right += 1
                print('combined-right', end_idx)
            else:
                break

        # 合并区域
        combined_parts = np.concatenate([left_parts, local_parts, right_parts])
        combined_start_idx = start_idx
        combined_end_idx = end_idx

        # 将合并的区域作为新的refine
        refined_outliers.extend(list(range(combined_start_idx, combined_end_idx)))
        print('!' * 20)

    return np.array(refined_outliers)


def exclude_indices(data, indices):
    if len(indices) == 0:  # 检查indices是否为空
        print('indices为空:',indices)
        return np.arange(data.shape[0])
    
    idx_arr = np.array(indices,dtype=int)
    mask = np.ones(data.shape[0], dtype=bool)
    mask[idx_arr] = False
    return np.where(mask)[0]


def fit_and_replace_outliers(data, outliers, degree=2):
    continuous_outliers_groups = safe_split_continuous_outliers(outliers)
    data_fitted = np.copy(data)

    for group in continuous_outliers_groups:
        x_values = np.array(group)
        y_values = data[x_values]
        if len(x_values) > 1:
            p_values = Polynomial.fit(x_values, y_values, degree)
            data_fitted[x_values] = p_values(x_values)

    return data_fitted
