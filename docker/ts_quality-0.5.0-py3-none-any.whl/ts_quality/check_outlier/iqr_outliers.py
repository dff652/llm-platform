"""
IQR 异常检测

基于四分位距检测异常点，并合并邻近异常。
"""
import numpy as np
import pandas as pd

from .ensemble import iqr_find_anomaly_indices


def detect(data, threshold=1.5, merge_distance=600):
    """
    IQR 异常检测。

    Parameters
    ----------
    data : pd.DataFrame or pd.Series
        输入数据，单列
    threshold : float
        IQR 倍数，默认 1.5
    merge_distance : int
        邻近异常合并距离，默认 600

    Returns
    -------
    np.ndarray[int]
        异常点的自然索引数组，已去重排序
    """
    if isinstance(data, pd.DataFrame):
        values = data.iloc[:, 0].values.ravel()
    elif isinstance(data, pd.Series):
        values = data.values.ravel()
    else:
        values = np.asarray(data).ravel()

    return iqr_find_anomaly_indices(values, th=threshold, N=merge_distance)
