"""
@File    :   check_outlier.py
@Time    :   2024/07/15 
@Author  :   DouFengfeng
@Version :   1.0.0
@Contact :   ff.dou@cyber-insight.com
@License :   (C)Copyright 2019-2026, CyberInsight
@Desc    :   时间序列异常检测
@Update  :   DouFengfeng, 2024/11/12

"""


import pandas as pd
import numpy as np

# 修复相对导入问题 - 改为绝对导入
from .signal_processing import ts_downsample, stl_decompose_cpu, check_time_continuity, \
    get_fulldata, min_max_scaling,variance_filter,get_true_indices,dead_value_detection, is_step_data, is_noisy_data, \
    adaptive_downsample, calculate_sampling_rate
from .ensemble import replace_outliers_by_3sigma, create_outlier_mask, iqr_find_anomaly_indices, \
    nsigma_find_anomaly_indices, piecewise_linear, standardized_find_anomaly_indices
from .wavelet import reconstruct_residuals, split_continuous_outliers, range_split_outliers,exclude_indices,\
    fit_and_replace_outliers,safe_split_continuous_outliers
from .isolation_forest import detect_isolation_forest
from scipy import signal
from scipy.signal import savgol_filter


def sigma_filtered_and_anomaly_detection(data, method='piecewise_linear', th=1.5, N=0.01):
    """
    使用sigma过滤和异常检测的组合方法
    
    Parameters
    ----
    data : pd.Series
        输入的时间序列数据
    method : str, optional
        异常检测方法，默认为'piecewise_linear'
        - 'piecewise_linear': 分段线性回归
        - 'wavelet': 小波分解
        - 'standardized': 标准化方法
        - 'iforest': 孤立森林
    th : float, optional
        异常检测阈值，默认为1.5
    N : float, optional
        合并长度参数，默认为0.01
        
    Returns
    ----
    outlier_mask : array-like
        异常值掩码
    anomaly_indices : array-like
        异常点索引
    """
    # 合并的数据长度取中数据长度的1/100或1/200
    if data.empty:
        print("Received empty data for processing.")
        return None, None, None, None
    data_length = len(data)
    merge_len = N
    if method == 'piecewise_linear':
        # 预处理
        # pre_data = replace_outliers_by_3sigma(data)

        window_length = min(601, data_length if data_length % 2 == 1 else data_length - 1)
        polyorder = min(3, window_length - 1)
        pre_data = savgol_filter(data.values.ravel(), window_length=window_length,
                                 polyorder=polyorder)  # 使用SG滤波，输入需要是array

        # 回归
        reconstruct_data, residuals = piecewise_linear(pre_data)

        if reconstruct_data is None or residuals is None:
            print("回归后结果为空，返回对应的mask全为0。")
            return np.zeros(data.shape[0]), [], np.zeros(data.shape[0]), np.zeros(data.shape[0])

        anomaly_indices = iqr_find_anomaly_indices(residuals, th, merge_len)  # 默认th=1.5

    elif method == 'wavelet':
        # 小波包
        min_max_data = min_max_scaling(data.values.ravel())
        # window_length = min(601, data_length if data_length % 2 == 1 else data_length - 1)
        # polyorder = min(3, window_length - 1)

        # pre_data = savgol_filter(min_max_data, window_length=window_length,
        #                         polyorder=polyorder)  # 使用SG滤波，输入需要是array
        reconstruct_data = reconstruct_residuals(min_max_data.ravel(), wavelet='db1', level=3)
        anomaly_indices = nsigma_find_anomaly_indices(reconstruct_data, th, merge_len)  # 默认th=5

        pre_data = None
    elif method == 'standardized':
        detrended_data = signal.detrend(data.values.ravel(), type='linear')
        anomaly_indices = standardized_find_anomaly_indices(detrended_data, th, merge_len)
        reconstruct_data = None
        pre_data = None

    elif method == 'iforest':
        min_max_data = min_max_scaling(data.values.ravel())
        window_length = min(61, data_length if data_length % 2 == 1 else data_length - 1)
        polyorder = min(1, window_length - 1)

        pre_data = savgol_filter(min_max_data, window_length=window_length,
                                 polyorder=polyorder)  # 使用SG滤波，输入需要是array
        reconstruct_data = reconstruct_residuals(pre_data.ravel(), wavelet='db1', level=3)
        anomaly_indices = detect_isolation_forest(data, outlier_ratio=th, N=merge_len)
        reconstruct_data = None
        pre_data = None

    outlier_mask = create_outlier_mask(data, anomaly_indices)

    print(f'---***---异常点数:{len(anomaly_indices)},数据长度:{len(data)},合并长度:{merge_len},阈值:{th} ---***---')
    return outlier_mask, anomaly_indices


def filter_data(data, mask='outlier_mask', threshold=2):
    """
    根据掩码过滤数据
    
    Parameters
    ----
    data : pd.DataFrame
        输入的数据
    mask : str, optional
        掩码列名，默认为'outlier_mask'
    threshold : int, optional
        阈值，默认为2
        
    Returns
    ----
    target_data : pd.DataFrame
        过滤后的数据
    """
    combine_masks = data.copy()
    combine_masks['label'] = combine_masks[mask].apply(lambda x: 1 if x >= threshold else 0)
    combine_masks['Group'] = (combine_masks['label'] != combine_masks['label'].shift()).cumsum()
    label_data = combine_masks[combine_masks['label'] == 1]
    grouped = label_data.groupby('Group')

    target_data = pd.DataFrame(columns=['variable', 'start_time', 'end_time'])
    for name, group in grouped:
        start_time = group.index.min()  # 获取组的最小时间作为开始时间
        end_time = group.index.max()  # 获取组的最大时间作为结束时间
        sensor = label_data.columns[0]  # 获取测点的列名，假设第一列是测点
        # tag = '标记'  # 标签信息，固定为 '标记'

        # 将结果添加到 target_data 中
        target_data = pd.concat([target_data, pd.DataFrame({
            'variable': [sensor],
            'start_time': [start_time],
            'end_time': [end_time],
            'mask': [mask],
        })], ignore_index=True)

    return target_data


def stl_wavelet_detect_old(data: pd.DataFrame,
              downsampler: str = 'm4',
              sample_param: float = 0.1,
              method: str = 'wavelet',
              threshold: float = 8,
              num_points: int = 1200,
              range_threshold: float = 0.2,
              insert_missing=True,
              decompose: bool = True,
              min_threshold: int = 200000):
    """
    使用STL分解和异常检测处理时间序列数据
    
    Parameters
    ----
    data : pd.DataFrame
        输入数据
    downsampler : str, optional
        降采样方法，支持'm4', 'minmax', 'none'或None，为None或'none'时不降采样，默认为'm4'
    sample_param : float, optional
        采样参数，默认为0.1
        - 0到1之间按比例降采样(例如0.1表示保留10%)
        - 大于1时自动使用min_threshold作为固定降采样数量
    method : str, optional
        异常检测方法，默认为'wavelet'
    threshold : float, optional
        异常检测阈值，默认为8
    num_points : int, optional
        在一个窗口中合并的点数，默认为1200
    range_threshold : float, optional
        范围划分阈值，默认为0.2
    insert_missing : bool, optional
        是否插入缺失值，默认为True
    decompose : bool, optional
        是否进行STL分解，默认为True
    min_threshold : int, optional
        最小阈值，默认为200000
        1. 当数据量小于此值时不进行降采样
        2. 当sample_param > 1时，作为固定降采样数量
        
    Returns
    ----
    raw_data : pd.DataFrame
        带有异常标记的原始数据
    """
    if not isinstance(data.index, pd.DatetimeIndex):
        try:
            data.index = pd.to_datetime(data.index)
        except Exception as e:
            raise ValueError("Index must be convertible to DatetimeIndex for STL method. "
                            "Current index type: {}. Error: {}".format(type(data.index), e))
        
    raw_data = data.copy()
    columns_to_check = raw_data.columns
    column = columns_to_check[0]
    
    if insert_missing:
        data = get_fulldata(raw_data, column)
        
    downsampled_data, ts = adaptive_downsample(
        data[column], 
        downsampler=downsampler, 
        sample_param=sample_param,
        min_threshold=min_threshold
    )
    label_data = pd.DataFrame()
    label_data.index = ts
    label_data[column] = downsampled_data
    sampling_rate = calculate_sampling_rate(data[column])
    step_type = is_step_data(raw_data)
    noise_type = is_noisy_data(label_data[column],fs =sampling_rate)
    data_type = []
    if step_type: data_type.append("step")
    if noise_type: data_type.append("noise")
    # print(f"数据类型: {data_type}")
    global_indices = np.array([], dtype=int)
    local_indices = np.array([], dtype=int)
    if "step" not in data_type and "noise" not in data_type:
        if decompose:
            # 健壮性检查，防止传递非法数据给 C 扩展
            if len(downsampled_data) == 0:
                raise ValueError("downsampled_data is empty!")
            if np.any(pd.isnull(downsampled_data)):
                raise ValueError("downsampled_data contains NaN!")
            if not np.issubdtype(np.array(downsampled_data).dtype, np.floating):
                downsampled_data = np.array(downsampled_data, dtype=float)
            df_trend, df_seasonal, df_resid = stl_decompose_cpu(downsampled_data, period=60)

            # 使用全局参数处理异常检测
            trend_outlier_mask, trend__indices = sigma_filtered_and_anomaly_detection(
                df_trend, method, threshold, num_points)
            resid_outlier_mask, resid__indices = sigma_filtered_and_anomaly_detection(
                df_resid, method, threshold, num_points)

            trend__indices = trend__indices.astype(int)
            resid__indices = resid__indices.astype(int)

            combined_array = np.concatenate((trend__indices, resid__indices))
            unique_array = np.unique(combined_array)
            
            
            anomaly_group = safe_split_continuous_outliers(unique_array)
            global_indices, local_indices = range_split_outliers(label_data, anomaly_group, range_threshold)  # 返回的是全局异常和局部异常
        else:
            # 不使用STL分解的情况
            outlier_mask, anomaly_indices = sigma_filtered_and_anomaly_detection(
                label_data, method, threshold, num_points)
            
            
            anomaly_group = safe_split_continuous_outliers(anomaly_indices)
            global_indices, local_indices = range_split_outliers(label_data, anomaly_group, range_threshold)

        # 加入长时间死值检测 
        detection_dead_value = True  
        if detection_dead_value:
            _,dead_df,_ = dead_value_detection(label_data,72000)
            
            dead_per = dead_df.sum()/len(dead_df)
            dead_per = dead_per.values[0]
            if dead_per < 0.7: # 死值比例小于0.7进行标记，大于0.7不进行标记
                natural_indices = get_true_indices(dead_df)
                global_list = global_indices.tolist()
                global_list.extend(natural_indices)
                global_indices = np.unique(global_list)
        
        
        # 加入偏离检测
        detection_deviation = True  
        fitted = True
        if detection_deviation:
            if fitted:
                data_arr = label_data.values.ravel()
                exclude_anomaly_idx = exclude_indices(data_arr, global_indices)
                data_fitted = fit_and_replace_outliers(data_arr, exclude_anomaly_idx, 2)
                # 修复 DataFrame 赋值警告
                label_data.loc[:, column] = data_fitted
        
            global_mask = create_outlier_mask(label_data, global_indices)
            label_data['global_mask'] = global_mask
            
            # print(global_mask.sum())
            outlier_masks = []
            outlier_masks.append(label_data)
            combined_data = pd.concat(outlier_masks)
            combined_data = variance_filter(combined_data, 'global_mask', 'mean', 0.5)
        
            label_data = combined_data.copy()
        else:
            global_mask = create_outlier_mask(label_data, global_indices)
            label_data['global_mask'] = global_mask
    else:
        # 对于阶梯型或噪声型数据，创建空掩码
        global_mask = create_outlier_mask(label_data, global_indices)
        label_data['global_mask'] = global_mask
    
    label_data['Group'] = (label_data['global_mask'] != label_data['global_mask'].shift()).cumsum()

    # 处理每一组 Group
    grouped = label_data[label_data['global_mask'] == 1].groupby('Group')

    # 新增一列作为标记列，初始化为 0
    raw_data[column] = False

    for name, group in grouped:
        start_time = group.index.min()  # 获取组的最小时间作为开始时间
        end_time = group.index.max()  # 获取组的最大时间作为结束时间

        # 将原始数据在该时间范围内的 'label' 列设置为 1
        raw_data.loc[(raw_data.index >= start_time) & (raw_data.index <= end_time), column] = True

    return raw_data
