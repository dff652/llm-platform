"""
时间连续性检测模块

包含时间连续性检测相关的函数
"""

import pandas as pd
from .utils import timer_decorator


@timer_decorator
def check_time_continuity_skipna(data, discontinuity_threshold=None):
    """
    检查时间序列的连续性
    
    Parameters
    ----
    data : pd.DataFrame
        输入的数据集，索引为时间戳
    discontinuity_threshold : int, optional
        采样间隔，以秒为单位，默认为自动推断
        
    Returns
    ----
    continuity : pd.Series
        布尔类型序列，标记每个间隔是否超过采样频率
    """
    ts = 'ts'
    time_index = pd.DataFrame(columns=[ts], index=data.index)
    time_index[ts] = data.index
    interval = (time_index[ts] - time_index[ts].shift(1))
    interval_seconds = interval.dt.total_seconds()

    if discontinuity_threshold is None or discontinuity_threshold == '':
        # 根据数据中的时间间隔推断采样频率
        discontinuity_threshold = interval_seconds.mode()[0]
    else:
        discontinuity_threshold = int(discontinuity_threshold)

    continuity = interval_seconds > int(discontinuity_threshold)
    continuity_ratio = continuity.sum() / len(interval_seconds)

    start_time = time_index[ts].min()
    end_time = time_index[ts].max()
    freq = f'{int(discontinuity_threshold)}s'

    if freq is None:
        raise ValueError("无法推断时间序列的频率，请确保输入是有序时间戳序列")

    # 构造完整的时间戳序列
    full_timestamps = pd.date_range(start=start_time, end=end_time, freq=freq)

    # 找出缺少的时间戳
    missing_timestamps = full_timestamps.difference(time_index[ts])

    # 创建布尔序列以标记缺失和不连续的时间戳
    continuity = pd.Series(False, index=full_timestamps)
    continuity[missing_timestamps] = True  # 标记缺失的时间戳为 True

    missing_count = continuity.sum()

    # 计算缺少时间戳的比例
    missing_ratio = missing_count / len(data)

    result_df = pd.DataFrame({
        f'missing_ratio': [missing_ratio],
        f'missing_timestamps_count': [missing_count]
    }).transpose()

    return  continuity


def check_time_continuity_global(df: pd.DataFrame,
                                 st_global: str,
                                 et_global: str,
                                 discontinuity_threshold=None,
                                 only_index=False
                                 ) -> pd.DataFrame:
    """
    获取全数据
    
    Parameters
    ----
    df : pd.DataFrame
        有效数据集
    st_global : str
        页面选取的开始时间
    et_global : str
        页面选取的结束时间
    discontinuity_threshold : int, optional
        采样间隔，默认为自动推断
    only_index : bool, optional
        是否只返回索引，默认为False
        
    Returns
    ----
    global_indices : pd.DataFrame or pd.DatetimeIndex
        全数据索引，当only_index=True时返回DatetimeIndex
    """
    data = df.copy()
    
    # logging.debug calls can be added here if needed
    # 确保 st_global 是 pd.Timestamp 类型
    # if isinstance(st_global, str):
    #     st_global = pd.Timestamp(st_global)
    # elif not isinstance(st_global, pd.Timestamp):
    #     st_global = pd.Timestamp(st_global)
    
    # # 确保 et_global 是 pd.Timestamp 类型
    # if isinstance(et_global, str):
    #     et_global = pd.Timestamp(et_global)
    # elif not isinstance(et_global, pd.Timestamp):
    #     et_global = pd.Timestamp(et_global)
    # logging.debug calls can be added here if needed
    ts = 'ts'
    time_index = pd.DataFrame()
    time_index[ts] = data.index
    interval = (time_index[ts] - time_index[ts].shift(1))
    interval_seconds = interval.dt.total_seconds()

    if discontinuity_threshold is None or discontinuity_threshold == '':
        # 根据数据中的时间间隔推断采样频率
        discontinuity_threshold = interval_seconds.mode()[0]
    else:
        discontinuity_threshold = int(discontinuity_threshold)

    freq = f'{int(discontinuity_threshold)}s'

    # 构造完整的时间戳序列
    global_timestamps = pd.date_range(start=st_global, end=et_global, freq=freq)

    global_indices = pd.DataFrame(data=True, index=global_timestamps, columns=data.columns)
    global_indices.index = global_indices.index.tz_localize('Asia/Shanghai')
    
    if only_index:
        return global_indices.index
    
    else:
        local_timestamps = data.index
        global_indices.loc[global_indices.index.isin(local_timestamps), :] = False
        return global_indices



def get_global_indices(data: pd.DataFrame,
                       st_global: str,
                       et_global: str,
                       discontinuity_threshold=None
                       ) -> pd.DataFrame:
    """
    获取全数据
    
    Parameters
    ----
    data : pd.DataFrame
        输入数据集
    st_global : str
        页面选取的开始时间
    et_global : str
        页面选取的结束时间
    discontinuity_threshold : int, optional
        采样间隔，默认为自动推断

    Returns
    ----
    global_indices : pd.DataFrame
        全数据索引
    """
    # 确保 st_global 是 pd.Timestamp 类型
    if not isinstance(st_global, pd.Timestamp):
        if isinstance(st_global, str):
            st_global = pd.to_datetime(st_global)
        else:
            st_global = pd.Timestamp(st_global)
    
    # 确保 et_global 是 pd.Timestamp 类型
    if not isinstance(et_global, pd.Timestamp):
        if isinstance(et_global, str):
            et_global = pd.to_datetime(et_global)
        else:
            et_global = pd.Timestamp(et_global)

    # 构造完整的时间戳序列
    global_timestamps = pd.date_range(start=st_global, end=et_global, freq= f'{int(discontinuity_threshold)}s')
    global_timestamps = global_timestamps.tz_localize('Asia/Shanghai')
    global_indices = pd.DataFrame(data=False, index=global_timestamps, columns=data.columns)
    return global_indices


