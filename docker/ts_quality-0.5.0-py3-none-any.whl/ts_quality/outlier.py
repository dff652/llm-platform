"""
异常值检测模块

包含异常值检测相关的函数
"""

import numpy as np
import pandas as pd
import warnings
# 全局抑制 pandas 即将默认启用 Copy-on-Write 后的 ChainedAssignmentError 提示
# 测试日志中大量出现的 FutureWarning: ChainedAssignmentError 来自 pandas
warnings.filterwarnings("ignore", message=".*ChainedAssignmentError.*", category=FutureWarning)
from sklearn.ensemble import IsolationForest
from .utils import timer_decorator, check_state

# 导入统一的算法入口
try:
    from .check_outlier.n_sigma import detect as _n_sigma_detect
    from .check_outlier.iqr_outliers import detect as _iqr_outliers_detect
    from .check_outlier.ensemble import detect as _ensemble_detect
    from .check_outlier.wavelet import detect as _wavelet_detect
    from .check_outlier.isolation_forest import detect as _isolation_forest_detect
    from .check_outlier.stl_wavelet import stl_wavelet_detect
    from .check_outlier.adtk_hbos import detect as _adtk_hbos_detect
    from .check_outlier.adtk_hbos import adtk_hbos_detect

    # 底层原语（向后兼容）
    from .check_outlier.signal_processing import (
        ts_downsample,
        check_time_continuity, get_fulldata, min_max_scaling, variance_filter,
        get_true_indices, dead_value_detection, is_step_data, is_noisy_data,
        adaptive_downsample, calculate_sampling_rate
    )
    from .check_outlier.ensemble import (
        replace_outliers_by_3sigma, create_outlier_mask, iqr_find_anomaly_indices,
        nsigma_find_anomaly_indices, piecewise_linear, standardized_find_anomaly_indices
    )
    from .check_outlier.wavelet import (
        reconstruct_residuals, safe_split_continuous_outliers, range_split_outliers,
        exclude_indices, fit_and_replace_outliers
    )
    from .check_outlier.isolation_forest import detect_isolation_forest
    from scipy import signal
    from scipy.signal import savgol_filter
    TS_OUTLIER_AVAILABLE = True
except ImportError as e:
    print(f"警告: 无法导入ts_outlier相关模块: {e}")
    TS_OUTLIER_AVAILABLE = False


def n_sigma(data, outlevel=5):
    """
    使用给定数据的均值和标准差计算阈值。

    Parameters
    ----
    data : array-like
        输入的数据
    outlevel : float, optional
        偏差倍数，用于计算阈值，默认为5

    Returns
    ----
    outlier_mask : array-like
        异常值的布尔掩码
    """
    mean = np.mean(data)
    std = np.std(data)
    threshold1 = mean - outlevel * std
    threshold2 = mean + outlevel * std
    outlier_mask = (data < threshold1) | (data > threshold2)
    return outlier_mask


def iqr_outliers(data, k=1.5):
    """
    使用IQR方法计算给定数据的异常值阈值。

    Parameters
    ----
    data : array-like
        输入的数据
    k : float, optional
        倍数，用于计算IQR的阈值，默认为1.5

    Returns
    ----
    outlier_mask : array-like
        异常值的布尔掩码
    """
    Q1 = np.percentile(data, 25)  # 第一四分位数
    Q3 = np.percentile(data, 75)  # 第三四分位数
    IQR = Q3 - Q1  # 四分位距

    # 计算下界和上界
    lower_bound = Q1 - k * IQR
    upper_bound = Q3 + k * IQR

    # 异常值掩码，数据小于下界或大于上界
    outlier_mask = (data < lower_bound) | (data > upper_bound)

    return outlier_mask


def min_max_scale(data):
    """
    对数据进行0-1化处理，将数据缩放到[0, 1]的范围内。

    Parameters
    ----
    data : array-like
        输入的数据，可以是一维或二维的NumPy数组

    Returns
    ----
    scaled_data : array-like
        0-1化后的数据
    """
    min_val = np.min(data)
    max_val = np.max(data)
    scaled_data = (data - min_val) / (max_val - min_val)
    return scaled_data


def standardize(data):
    """
    对数据进行标准化处理，将数据转化为均值为0，标准差为1的分布。

    Parameters
    ----
    data : array-like
        输入的数据，可以是一维或二维的NumPy数组

    Returns
    ----
    standardized_data : array-like
        标准化后的数据
    """
    mean_val = np.mean(data)
    std_val = np.std(data)
    standardized_data = (data - mean_val) / std_val
    return standardized_data


def find_continuous_indexes(data, n):
    """
    判断数据索引是否连续，并输出连续的索引。

    Parameters
    ----
    data : list
        数据列表
    n : int
        间隔阈值

    Returns
    ----
    continuous_indexes : list
        连续的索引列表
    """
    continuous_indexes = []
    if len(data) == 0:
        return continuous_indexes

    indexes = sorted(data)

    start = indexes[0]
    end = indexes[0]
    for i in range(1, len(indexes)):
        if indexes[i] - end <= n:
            end = indexes[i]
        else:
            if end - start >= n:
                continuous_indexes.extend(range(start, end + 1))
            start = indexes[i]
            end = indexes[i]

    if end - start >= n:
        continuous_indexes.extend(range(start, end + 1))

    return continuous_indexes


def piecewise_linear(df, threshold):
    """
    使用分段线性回归检测跳变。

    Parameters
    ----
    df : pd.Series or pd.DataFrame
        输入的时间序列数据
    threshold : float
        阈值，用于确定跳变

    Returns
    ----
    df_copy : pd.DataFrame
        异常值的布尔掩码
    """

    # data = min_max_scale(df.values).ravel()
    data = df.values.ravel()
    n = len(data)

    # 首尾各去除10%数据点，分别进行2阶多项式拟合
    trim_size = int(0.1 * n)
    coefficients_start = np.polyfit(np.arange(trim_size), data[:trim_size], 2)
    coefficients_end = np.polyfit(np.arange(n - trim_size, n), data[-trim_size:], 2)

    # 整体12阶多项式拟合
    coefficients = np.polyfit(np.arange(n), data, 12)
    fitted_curve = np.polyval(coefficients, np.arange(n))

    # 拼接拟合结果
    fitted_curve[:trim_size] = np.polyval(coefficients_start, np.arange(trim_size))
    fitted_curve[n - trim_size:] = np.polyval(coefficients_end, np.arange(n - trim_size, n))

    # 计算每个点的残差
    residuals = np.abs(data - fitted_curve)

    # 计算残差的均值和标准差
    mean_res = np.mean(residuals)
    std_res = np.std(residuals)

    # 确定阈值
    threshold_value = mean_res + threshold * std_res

    # 检测跳变
    change_points = []

    for i in range(1, n - 1):
        # 检查当前残差值、前一个残差值和后一个残差值是否都大于门槛值
        if residuals[i] > threshold_value and residuals[i - 1] > threshold_value and residuals[i + 1] > threshold_value \
                and residuals[i] > residuals[i - 1] and residuals[i] > residuals[i + 1]:
            if i != trim_size and i != n - trim_size:
                change_points.append(i)

    # 寻找连续的跳变索引
    change_points = find_continuous_indexes(change_points, 30)
    # print(change_points)
    outlier_mask = np.full_like(data, False)
    outlier_mask[change_points] = True

    df_copy = df.copy()
    # 兼容 DataFrame 和 Series，防止链式赋值和属性错误
    if isinstance(df_copy, pd.DataFrame):
        df_copy.loc[:, df_copy.columns[0]] = outlier_mask
    elif isinstance(df_copy, pd.Series):
        df_copy.loc[:] = outlier_mask
    else:
        raise TypeError("df_copy must be DataFrame or Series")

    return df_copy


def detect_isolation_forest(data, outlier_ratio=0.01):
    """
    使用孤立森林检测异常值。

    Parameters
    ----
    data : pd.Series
        输入的数据
    outlier_ratio : float, optional
        异常值的比例，默认为0.01

    Returns
    ----
    outlier_mask : pd.Series
        异常值的布尔掩码
    """
    isolation_forest = IsolationForest(contamination=outlier_ratio)
    outliers = isolation_forest.fit_predict(data.values.reshape(-1, 1))
    df_outliers = pd.DataFrame(outliers, index=data.index, columns=['outliers'])
    outlier_mask = df_outliers['outliers'] == -1

    return outlier_mask


def replace_outliers_by_3sigma(data, th=3):
    """
    使用3sigma规则检测异常点。

    Parameters
    ----
    data : array-like
        包含数据的数组
    th : float, optional
        标准差倍数，默认为3

    Returns
    ----
    pre_data : array-like
        填充异常点后的数据数组副本
    """
    # 创建数据的副本
    pre_data = np.copy(data)
    pre_data = pre_data.ravel()
    mean_error = np.mean(pre_data)
    std_error = np.std(pre_data)

    # 设置3sigma阈值
    lower_bound = mean_error - th * std_error
    upper_bound = mean_error + th * std_error

    # 找到超过阈值的异常点的索引
    anomalies = np.where((pre_data < lower_bound) | (pre_data > upper_bound))[0]

    # 用均值填充异常点
    pre_data[anomalies] = mean_error

    return pre_data


def piecewise_linear_v1(df):
    """
    使用分段线性回归检测跳变。

    Parameters
    ----
    df : array-like
        输入的时间序列数据

    Returns
    ----
    fitted_curve : array-like
        拟合后的曲线数据
    """

    # data = min_max_scale(df.values).ravel()
    data = np.copy(df)
    n = len(data)

    # 首尾各去除10%数据点，分别进行2阶多项式拟合
    trim_size = int(0.1 * n)
    coefficients_start = np.polyfit(np.arange(trim_size), data[:trim_size], 2)
    coefficients_end = np.polyfit(np.arange(n - trim_size, n), data[-trim_size:], 2)

    # 整体12阶多项式拟合
    coefficients = np.polyfit(np.arange(n), data, 12)
    fitted_curve = np.polyval(coefficients, np.arange(n))

    # 拼接拟合结果
    fitted_curve[:trim_size] = np.polyval(coefficients_start, np.arange(trim_size))
    fitted_curve[n - trim_size:] = np.polyval(coefficients_end, np.arange(n - trim_size, n))

    return fitted_curve


def find_anomaly_indices(data, fitted_data, threshold, N):
    """
    检测异常点，并返回两个异常点之间的点数不超过N的段的下标。

    Parameters
    ----
    data : array-like
        原始数据
    fitted_data : array-like
        拟合数据
    threshold : float
        用于确定异常点的阈值倍数
    N : int
        两个异常点之间的最大点数，如果小于这个数，则整段数据都标记为异常

    Returns
    ----
    continuous_anomalies : array-like
        异常点的下标数组
    """
    # 计算误差的平均值和标准差
    residual = np.abs(data - fitted_data)

    mean_error = np.mean(residual)
    std_error = np.std(residual)

    # 设置阈值
    threshold_value = mean_error + threshold * std_error

    # 找到超过阈值的异常点
    anomaly_indices = np.where(residual > threshold_value)[0]

    # 如果异常点数量为0，直接返回空数组
    if len(anomaly_indices) == 0:
        return np.array([], dtype=int)

    # 找到连续的异常段
    continuous_anomalies = []
    start_idx = anomaly_indices[0]
    end_idx = anomaly_indices[0]

    for i in range(1, len(anomaly_indices)):
        if anomaly_indices[i] - end_idx <= N:
            end_idx = anomaly_indices[i]
        else:
            # 如果当前段长度大于等于N，则整段都标记为异常
            if end_idx - start_idx >= N:
                continuous_anomalies.extend(range(start_idx, end_idx + 1))
            start_idx = anomaly_indices[i]
            end_idx = anomaly_indices[i]

    # 处理最后一段
    if end_idx - start_idx >= N:
        continuous_anomalies.extend(range(start_idx, end_idx + 1))

    # 确保返回的是整数数组
    return np.array(continuous_anomalies, dtype=int)


def create_outlier_mask(df, anomaly):
    """
    创建异常值掩码

    Parameters
    ----
    df : pd.DataFrame
        原始数据
    anomaly : array-like
        异常点索引

    Returns
    ----
    df_copy : pd.DataFrame
        异常值掩码
    """
    # 确保 anomaly 是整数类型的数组
    if anomaly is None or len(anomaly) == 0:
        anomaly = np.array([], dtype=int)
    else:
        # 转换为整数数组，过滤掉非数字元素
        try:
            anomaly = np.array(anomaly, dtype=int)
        except (ValueError, TypeError):
            # 如果转换失败，尝试过滤并重新转换
            filtered_anomaly = []
            for item in anomaly:
                if isinstance(item, (int, np.integer)) and not isinstance(item, bool):
                    filtered_anomaly.append(int(item))
                elif isinstance(item, float) and not np.isnan(item) and item == int(item):
                    filtered_anomaly.append(int(item))
            anomaly = np.array(filtered_anomaly, dtype=int)
    
    outlier_mask = np.full_like(df.values, False)
    if len(anomaly) > 0:
        # 确保索引在有效范围内
        valid_indices = anomaly[(anomaly >= 0) & (anomaly < len(outlier_mask))]
        outlier_mask[valid_indices] = True
    
    df_copy = df.copy()
    # 兼容 DataFrame 和 Series，防止链式赋值和属性错误
    if isinstance(df_copy, pd.DataFrame):
        df_copy.loc[:, df_copy.columns[0]] = outlier_mask
    elif isinstance(df_copy, pd.Series):
        df_copy.loc[:] = outlier_mask
    else:
        raise TypeError("df_copy must be DataFrame or Series")
    return df_copy


def sigma_filtered_and_piecewise_linear(data, th=3, N=600):
    """
    使用3sigma过滤和分段线性回归的组合方法检测异常值

    Parameters
    ----
    data : pd.Series
        输入数据
    th : float, optional
        3sigma阈值倍数，默认为3
    N : int, optional
        连续异常段的最小长度，默认为600

    Returns
    ----
    outlier_mask : pd.DataFrame
        异常值掩码
    anomaly_indices : array-like
        异常点索引
    fitted_curve : array-like
        拟合曲线
    pre_data : array-like
        预处理数据
    """
    # 使用3sigma规则预处理数据
    pre_data = replace_outliers_by_3sigma(data, th)
    
    # 使用分段线性回归拟合
    fitted_curve = piecewise_linear_v1(pre_data)
    
    # 检测异常点
    anomaly_indices = find_anomaly_indices(data, fitted_curve, th, N)
    
    # 创建异常值掩码
    outlier_mask = create_outlier_mask(data, anomaly_indices)
    
    return outlier_mask, anomaly_indices, fitted_curve, pre_data


# @timer_decorator
# def check_outlier(data,
#                   method='stl',
#                   outlier_threshold=8,
#                   distinct_threshold=10,
#                   sample_param=2,
#                   min_threshold=500000,
#                   range_threshold=0.2, 
#                   num_points=1200,
#                   use_pipeline=False,
#                   pipeline_config=None
#                   ):
#     """
#     检查每列数据中的异常值比例

#     Parameters
#     ----
#     data : pd.DataFrame
#         输入的数据集
#     method : str, optional
#         异常检测算法，默认为'stl'
#         - 'piecewise_linear': 基于残差阈值判断
#         - 'n_sigma': 基于标准差判断
#         - 'isolation_forest': 基于孤立森林判断
#         - 'iqr_outliers': 基于IQR判断
#         - 'ensemble': 基于集成法判断
#         - 'stl_wavelet': 基于STL分解并使用Wavelet进行异常检测
#         - 'adtk_hbos': 基于ADTK-HBOS检测
#         - 'mean_shift': 基于Mean Shift检测
#         - 'pipeline': 使用Pipeline模式组合多个算法
#     outlier_threshold : float, optional
#         异常检测阈值，默认为0.2
#         - piecewise_linear: 分段线性回归的残差阈值，默认为4.6
#         - n_sigma: 超出数据标准差的倍数，默认为3
#         - isolation_forest: 孤立森林异常比例，默认为0.01
#         - iqr_outliers: IQR的倍数，默认为1.5
#         - ensemble: 分段线性回归的残差阈值，默认为4.6
#         - stl_wavelet: 小波异常检测的阈值，默认为8
#     distinct_threshold : int, optional
#         检查数据唯一值的阈值，默认为10
#     sample_param : float, optional
#         采样参数，默认为0.1,取值范围0-1表示采样比例，大于1表示使用采样点数min_threshold
#     min_threshold : int, optional
#         最小阈值，默认为500000
#     range_threshold : float, optional
#         全局和局部异常分割比例，默认为0.2，取值范围0-1，0.2表示20%的异常为全局异常，80%的异常为局部异常
#     num_points : int, optional
#         异常后处理阈值，默认为1200，表示异常点数量超过1200个时，进行异常后处理
#     use_pipeline : bool, optional
#         是否使用Pipeline模式，默认为False
#     pipeline_config : str, optional
#         Pipeline配置名称，支持'stl_hbos', 'conditional'等，默认为None

#     Returns
#     ----
#     outlier_indices : pd.DataFrame
#         每列中异常值的位置（布尔索引）
#     """
#     columns_to_check = data.columns
#     result_dfs = []
#     outlier_indices = {}
#     columns_with_outliers = []

#     for col in columns_to_check:

#         value_len = check_state(data, col)
#         if value_len < distinct_threshold:
#             temp_df = pd.DataFrame({
#                 'outlier_rate': [0.0],
#                 'outlier_count': [0]
#             }).transpose()
#             result_dfs.append(temp_df)
#             outlier_indices[col] = np.zeros(len(data), dtype=bool)

#         else:
#             # 使用Pipeline模式
#             if use_pipeline or method == 'pipeline':
#                 outlier_mask = _detect_with_pipeline(
#                     data[col], 
#                     pipeline_config, 
#                     outlier_threshold, 
#                     range_threshold, 
#                     num_points
#                 )
#             else:
#                 # 使用传统单算法模式
#                 outlier_mask = _detect_with_single_method(
#                     data[col], 
#                     method, 
#                     outlier_threshold, 
#                     range_threshold, 
#                     num_points
#                 )

#             outlier_indices[col] = outlier_mask

#     # 创建包含异常值的布尔 DataFrame
#     outlier_indices = pd.DataFrame(outlier_indices, index=data.index)

#     # 提取包含异常值的行，并只包括进行了异常值检查的列
#     outlier_data = data.loc[outlier_indices.any(axis=1), columns_with_outliers]

#     return outlier_indices


# def _detect_with_pipeline(data_column, pipeline_config, outlier_threshold, range_threshold, num_points):
#     """
#     使用Pipeline模式进行异常检测
    
#     Parameters
#     ----
#     data_column : pd.Series
#         单列数据
#     pipeline_config : str
#         Pipeline配置名称
#     outlier_threshold : float
#         异常检测阈值
#     range_threshold : float
#         范围阈值
#     num_points : int
#         点数阈值
        
#     Returns
#     ----
#     pd.Series
#         异常掩码
#     """
#     try:
#         from .check_outlier.anomaly_pipeline import (
#             create_stl_hbos_pipeline, 
#             create_conditional_pipeline,
#             AnomalyDetectionPipeline
#         )
        
#         # 根据配置创建Pipeline
#         if pipeline_config == 'stl_hbos':
#             pipeline = create_stl_hbos_pipeline()
#         elif pipeline_config == 'conditional':
#             pipeline = create_conditional_pipeline()
#         else:
#             # 默认创建STL-HBOS组合Pipeline
#             pipeline = create_stl_hbos_pipeline()
        
#         # 将单列数据转换为DataFrame格式
#         data_df = pd.DataFrame({data_column.name: data_column})
        
#         # 执行Pipeline检测
#         result = pipeline.detect(data_df)
        
#         # 返回异常掩码
#         return result[data_column.name]
        
#     except ImportError as e:
#         print(f"Pipeline模块导入失败: {e}")
#         print("回退到传统检测方法")
#         return _detect_with_single_method(
#             data_column, 'stl_wavelet', outlier_threshold, range_threshold, num_points
#         )
    


@timer_decorator
def check_outlier(data,
                  method='stl',
                  outlier_threshold=8,
                  distinct_threshold=10,
                  sample_param=0.1,
                  min_threshold=500000,
                  range_threshold=0.2, 
                  num_points=1200,
                  bin_nums=20,
                  ratio=None
                  ):
    """
    检查每列数据中的异常值比例

    Parameters
    ----
    data : pd.DataFrame
        输入的数据集
    method : str, optional
        异常检测算法，默认为'stl'
        - 'piecewise_linear': 基于残差阈值判断
        - 'n_sigma': 基于标准差判断
        - 'isolation_forest': 基于孤立森林判断
        - 'iqr_outliers': 基于IQR判断
        - 'ensemble': 基于集成法判断
        - 'stl_wavelet': 基于STL分解并使用Wavelet进行异常检测（高性能版本）
        - 'adtk_hbos': 基于adtk_hbos进行异常检测
    outlier_threshold : float, optional
        异常检测阈值，默认为0.2
        - piecewise_linear: 分段线性回归的残差阈值，默认为4.6
        - n_sigma: 超出数据标准差的倍数，默认为3
        - isolation_forest: 孤立森林异常比例，默认为0.01
        - iqr_outliers: IQR的倍数，默认为1.5
        - ensemble: 分段线性回归的残差阈值，默认为4.6
        - stl_wavelet: STL异常检测的阈值，默认为8
        - adtk_hbos: adtk_hbos异常检测的阈值，默认为None
    distinct_threshold : int, optional
        检查数据唯一值的阈值，默认为10
    sample_param : float, optional
        采样参数，默认为0.1,取值范围0-1表示采样比例，大于1表示使用采样点数min_threshold
    min_threshold : int, optional
        最小阈值，默认为500000
    range_threshold : float, optional
        全局和局部异常分割比例，默认为0.2，取值范围0-1，0.2表示20%的异常为全局异常，80%的异常为局部异常
    num_points : int, optional
        异常后处理阈值，默认为1200，表示异常点数量超过1200个时，进行异常后处理
    bin_nums : int, optional
        adtk_hbos分箱数量，默认为20
    ratio : float, optional
        adtk_hbos异常比例，默认为None

    Returns
    ----
    outlier_indices : pd.DataFrame
        每列中异常值的位置（布尔索引）
    """
    # 抑制链式赋值警告
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message=".*ChainedAssignmentError.*", category=FutureWarning)
        
        columns_to_check = data.columns
        result_dfs = []
        outlier_indices = {}
        columns_with_outliers = []

        for col in columns_to_check:

            value_len = check_state(data, col)
            if value_len < distinct_threshold:
                temp_df = pd.DataFrame({
                    'outlier_rate': [0.0],
                    'outlier_count': [0]
                }).transpose()
                result_dfs.append(temp_df)
                outlier_indices[col] = np.zeros(len(data), dtype=bool)

            else:

                if not TS_OUTLIER_AVAILABLE and method in ('stl_wavelet', 'adtk_hbos', 'ensemble', 'wavelet', 'isolation_forest'):
                    raise ImportError(f"ts_outlier相关模块不可用，无法使用{method}方法")

                if method == 'n_sigma':
                    anomaly_indices = _n_sigma_detect(data[[col]], threshold=outlier_threshold)
                    outlier_mask = np.zeros(len(data), dtype=bool)
                    if len(anomaly_indices) > 0:
                        valid = anomaly_indices[anomaly_indices < len(data)]
                        outlier_mask[valid] = True

                elif method == 'iqr_outliers':
                    anomaly_indices = _iqr_outliers_detect(data[[col]], threshold=outlier_threshold)
                    outlier_mask = np.zeros(len(data), dtype=bool)
                    if len(anomaly_indices) > 0:
                        valid = anomaly_indices[anomaly_indices < len(data)]
                        outlier_mask[valid] = True

                elif method in ('piecewise_linear', 'ensemble'):
                    anomaly_indices = _ensemble_detect(data[[col]], threshold=outlier_threshold)
                    outlier_mask = np.zeros(len(data), dtype=bool)
                    if len(anomaly_indices) > 0:
                        valid = anomaly_indices[anomaly_indices < len(data)]
                        outlier_mask[valid] = True

                elif method == 'wavelet':
                    anomaly_indices = _wavelet_detect(data[[col]], threshold=outlier_threshold)
                    outlier_mask = np.zeros(len(data), dtype=bool)
                    if len(anomaly_indices) > 0:
                        valid = anomaly_indices[anomaly_indices < len(data)]
                        outlier_mask[valid] = True

                elif method == 'isolation_forest':
                    anomaly_indices = _isolation_forest_detect(data[[col]], contamination=outlier_threshold)
                    outlier_mask = np.zeros(len(data), dtype=bool)
                    if len(anomaly_indices) > 0:
                        valid = anomaly_indices[anomaly_indices < len(data)]
                        outlier_mask[valid] = True

                elif method == 'stl_wavelet':
                    result_df = stl_wavelet_detect(data,
                                                   downsampler='m4',
                                                   sample_param=sample_param,
                                                   method='wavelet',
                                                   threshold=outlier_threshold,
                                                   num_points=num_points,
                                                   range_threshold=range_threshold,
                                                   insert_missing=True,
                                                   decompose=True,
                                                   min_threshold=min_threshold)
                    outlier_mask = result_df[data.columns[0]]

                elif method == 'adtk_hbos':
                    result = adtk_hbos_detect(
                        data,
                        downsampler='m4',
                        sample_param=0.1,
                        bin_nums=bin_nums,
                        min_threshold=500000,
                        ratio=ratio
                    )
                    result_df = result[0] if isinstance(result, tuple) else result
                    outlier_mask = result_df[data.columns[0]]
       
            
        
                # elif method == 'stl':
                #     if not TS_OUTLIER_AVAILABLE:
                #         raise ImportError("ts_outlier相关模块不可用，无法使用global方法")
                    
                #     # 使用ts_outlier进行异常检测
                #     outlier_result = ts_outlier(
                #         data, 
                #         downsampler='m4', 
                #         sample_param=0.1, 
                #         method='wavelet', 
                #         threshold=outlier_threshold, 
                #         num_points=1200, 
                #         range_threshold=range_threshold, 
                #         insert_missing=True, 
                #         decompose=True, 
                #         min_threshold=500000
                #     )
                    
                #     # 创建异常值掩码
                #     outlier_mask = outlier_result[data.columns[0]]
                    
                #     # 计算异常值统计
                #     count_outlier = outlier_mask.sum()
                #     count_total = len(data)
                #     outlier_rate = count_outlier / count_total
                    
                #     if outlier_rate > 0:
                #         columns_with_outliers.append(data.columns[0])
                    
                #     temp_df = pd.DataFrame({
                #         f'outlier_rate': [outlier_rate],
                #         f'outlier_count': [count_outlier]
                #     }).transpose()
                    
                #     result_dfs.append(temp_df)
                #     outlier_indices[data.columns[0]] = outlier_mask
                    
                #     # 对于global方法，直接返回结果
                #     result_df = pd.concat(result_dfs, axis=1)
                #     result_df.columns = data.columns
                #     outlier_indices = pd.DataFrame(outlier_indices, index=data.index)
                #     outlier_data = data.loc[outlier_indices.any(axis=1), columns_with_outliers]
                    
                #     return  outlier_indices

                #         count_outlier = outlier_mask.sum()
                #         count_total = len(data)
                #         outlier_rate = count_outlier / count_total

                #         if outlier_rate > 0:
                #             columns_with_outliers.append(col)

                #         temp_df = pd.DataFrame({
                #             f'outlier_rate': [outlier_rate],
                #             f'outlier_count': [count_outlier]
                #         }).transpose()

                #         result_dfs.append(temp_df)
                #         outlier_indices[col] = outlier_mask

                # result_df = pd.concat(result_dfs, axis=1)
                # result_df.columns = columns_to_check

                # # 创建包含异常值的布尔 DataFrame
                # outlier_indices = pd.DataFrame(outlier_indices, index=data.index)

                # # 提取包含异常值的行，并只包括进行了异常值检查的列
                # outlier_data = data.loc[outlier_indices.any(axis=1), columns_with_outliers]

        return  outlier_mask




# def _detect_with_single_method(data_column, method, outlier_threshold, range_threshold, num_points, bin_nums=20, ratio=None):
#     """
#     使用传统单算法模式进行异常检测
    
#     Parameters
#     ----
#     data_column : pd.Series
#         单列数据
#     method : str
#         检测方法
#     outlier_threshold : float
#         异常检测阈值
#     range_threshold : float
#         范围阈值
#     num_points : int
#         点数阈值
        
#     Returns
#     ----
#     pd.Series
#         异常掩码
#     """
#     if method == 'n_sigma':
#         outlier_mask = n_sigma(data_column, outlier_threshold)
#     elif method == 'piecewise_linear':
#         outlier_mask = piecewise_linear(data_column, outlier_threshold)
#     elif method == 'isolation_forest':
#         outlier_mask = detect_isolation_forest(data_column, outlier_threshold)
#     elif method == 'iqr_outliers':
#         outlier_mask = iqr_outliers(data_column, outlier_threshold)
#     elif method == 'ensemble':
#         # print('--->测试集成法<---')
#         outlier_mask, anomaly_indices, fitted_curve, pre_data = sigma_filtered_and_piecewise_linear(data_column, outlier_threshold, N=600)
#     elif method == 'stl_wavelet':
#         if not TS_OUTLIER_AVAILABLE:
#             raise ImportError("ts_outlier相关模块不可用，无法使用stl_wavelet方法")
        
#         outlier_result = stl_wavelet_detect(
#                 data_column.to_frame(), 
#                 downsampler='m4', 
#                 sample_param=0.1, 
#                 method='wavelet', 
#                 threshold=outlier_threshold, 
#                 num_points=num_points, 
#                 range_threshold=range_threshold, 
#                 insert_missing=True, 
#                 decompose=True, 
#                 min_threshold=500000
#             )
#         outlier_mask = outlier_result[data_column.name]
        
    
        
        # # 使用重构后的STLWaveletDetector
        # try:
        #     from .check_outlier.stl_wavelet import STLWaveletDetector
            
        #     detector = STLWaveletDetector(
        #         method='wavelet',
        #         threshold=outlier_threshold,
        #         num_points=num_points,
        #         range_threshold=range_threshold,
        #         min_threshold=500000
        #     )
            
        #     # 将单列数据转换为DataFrame格式
        #     data_df = pd.DataFrame({data_column.name: data_column})
        #     result = detector.detect(data_df)
        #     outlier_mask = result[data_column.name]
            
        # except ImportError:
        #     # 回退到原有方法
        #     outlier_result = stl_wavelet_detect(
        #         data_column.to_frame(), 
        #         downsampler='m4', 
        #         sample_param=0.1, 
        #         method='wavelet', 
        #         threshold=outlier_threshold, 
        #         num_points=num_points, 
        #         range_threshold=range_threshold, 
        #         insert_missing=True, 
        #         decompose=True, 
        #         min_threshold=500000
        #     )
        #     outlier_mask = outlier_result[data_column.name]
            
    # elif method == 'adtk_hbos':
    #     try:
    #         from .check_outlier.adtk_hbos_detect import AnomalyBordersDetector
            
    #         detector = AnomalyBordersDetector()
    #         data_df = pd.DataFrame({data_column.name: data_column})
    #         result = detector.detect(data_df)
    #         outlier_mask = result[data_column.name]
            
    #     except ImportError:
    #         # 回退到原有方法
    #         abd = AnomalyBordersDetector()
    #         anomaly_indices = abd.detect(data_column)
    #         outlier_mask = create_outlier_mask(data_column, anomaly_indices)
            
    # elif method == 'mean_shift':
    #     msd = MeanShiftDetect()
    #     anomaly_indices = msd.detect(data_column)
    #     outlier_mask = create_outlier_mask(data_column, anomaly_indices)
    # else:
    #     raise ValueError("无效的异常值检测方法")
    
    
    # elif method == 'jm_detect':
    #     if not TS_OUTLIER_AVAILABLE:
    #         raise ImportError("ts_outlier相关模块不可用，无法使用jm_detect方法")
        
    #     try:
    #         outlier_result = jm_anomaly_detect(
    #             data_column.to_frame(),
    #             downsampler='m4',
    #             sample_param=0.1,
    #             bin_nums=bin_nums,
    #             min_threshold=500000,
    #             ratio=ratio
    #         )
    #         outlier_mask = outlier_result[data_column.name]
    #     except Exception as e:
    #         print(f"jm_anomaly_detect方法执行失败: {e}")
    #         print("回退到piecewise_linear方法")
    #         outlier_mask = piecewise_linear(data_column, outlier_threshold)
    # else:
    #     raise ValueError("无效的异常值检测方法")
    
    # return outlier_mask

