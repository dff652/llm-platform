"""
跨项目版本兼容性检查。

ts_quality 作为底层包，在此声明对各消费方的最低版本要求。
消费方（ts-platform、ts-quality-evaluator）在启动时调用 check_compat() 验证。

用法::

    from ts_quality.compat import check_compat, version_banner

    # 启动时检查兼容性（不兼容则抛 RuntimeError）
    check_compat("ts-platform", "1.4.0")

    # 获取版本横幅字符串（写入日志）
    banner = version_banner("ts-platform", "1.4.0")
"""

import logging
from importlib.metadata import version as _pkg_version, PackageNotFoundError

from . import __version__

logger = logging.getLogger(__name__)

# ts_quality 各版本对消费方的最低版本要求
# 格式: {消费方名称: 最低版本}
# 含义: "当前 ts_quality 版本至少需要消费方 >= 此版本才能正常工作"
_MIN_CONSUMER_VERSIONS: dict[str, str] = {
    "ts-platform": "1.4.0",
    "ts-quality-evaluator": "0.2.0",
}

# 反向: 消费方对 ts_quality 的最低版本要求
# 消费方启动时传入自己的版本，此表用于检查 ts_quality 是否够新
_MIN_TSQUALITY_FOR: dict[str, str] = {
    "ts-platform": "0.5.0",
    "ts-quality-evaluator": "0.3.0",
}


def _parse_version(v: str) -> tuple[int, ...]:
    """将版本字符串解析为可比较的元组。"""
    return tuple(int(x) for x in v.split(".")[:3])


def check_compat(consumer_name: str, consumer_version: str, *, strict: bool = False) -> bool:
    """检查 ts_quality 与消费方的版本兼容性。

    Parameters
    ----------
    consumer_name : str
        消费方名称，如 "ts-platform" 或 "ts-quality-evaluator"
    consumer_version : str
        消费方当前版本号
    strict : bool
        True 时不兼容直接抛 RuntimeError；False 时仅 warning

    Returns
    -------
    bool
        True = 兼容，False = 不兼容（strict=False 时）

    Raises
    ------
    RuntimeError
        strict=True 且版本不兼容时
    """
    ok = True
    tsq_ver = _parse_version(__version__)
    consumer_ver = _parse_version(consumer_version)

    # 检查 1: 消费方版本是否满足 ts_quality 的要求
    min_consumer = _MIN_CONSUMER_VERSIONS.get(consumer_name)
    if min_consumer and consumer_ver < _parse_version(min_consumer):
        msg = (f"ts_quality {__version__} 要求 {consumer_name} >= {min_consumer}，"
               f"当前 {consumer_version}")
        ok = False
        if strict:
            raise RuntimeError(msg)
        logger.warning(msg)

    # 检查 2: ts_quality 版本是否满足消费方的要求
    min_tsq = _MIN_TSQUALITY_FOR.get(consumer_name)
    if min_tsq and tsq_ver < _parse_version(min_tsq):
        msg = (f"{consumer_name} {consumer_version} 要求 ts_quality >= {min_tsq}，"
               f"当前 {__version__}")
        ok = False
        if strict:
            raise RuntimeError(msg)
        logger.warning(msg)

    if ok:
        logger.info("版本兼容性检查通过: ts_quality=%s, %s=%s",
                     __version__, consumer_name, consumer_version)
    return ok


def version_banner(consumer_name: str, consumer_version: str) -> str:
    """生成包含所有相关版本信息的横幅字符串，用于启动日志。

    Returns
    -------
    str
        多行版本信息字符串
    """
    lines = [
        f"  {consumer_name}: {consumer_version}",
        f"  ts_quality: {__version__}",
    ]

    # 尝试读取关键依赖版本
    for pkg in ("numpy", "pandas", "scipy", "scikit-learn"):
        try:
            lines.append(f"  {pkg}: {_pkg_version(pkg)}")
        except PackageNotFoundError:
            pass

    return "\n".join(lines)
