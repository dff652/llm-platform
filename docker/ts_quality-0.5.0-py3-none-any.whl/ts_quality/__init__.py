"""
ts_quality — 时间序列数据质量检测算法包

支持的异常检测算法：
    n_sigma, iqr_outliers, ensemble, wavelet,
    isolation_forest, stl_wavelet, adtk_hbos

后处理算法：
    edge_align

评估指标：
    calculate_combined_metrics, evaluate_segments, avg_score
"""

__version__ = "0.5.0"
