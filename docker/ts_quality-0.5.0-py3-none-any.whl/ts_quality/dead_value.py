"""
死值检测模块

包含死值检测相关的函数
"""

import numpy as np
import pandas as pd
from .utils import timer_decorator, check_state


@timer_decorator
def dead_value_detection(data, duration_threshold=3600, distinct_threshold=10):
    """
    检测DataFrame中的死值（恒定值）
    
    Parameters
    ----
    data : pd.DataFrame
        输入的数据集
    duration_threshold : int, optional
        死值的持续时间阈值，默认为3600秒
    distinct_threshold : int, optional
        检查数据唯一值的阈值，默认为10
        
    Returns
    ----
    constant_indices : pd.DataFrame
        每列中死值的位置（布尔索引）
    """
    columns_to_check = data.columns
    result_dfs = []
    constant_indices = {}

    for col in columns_to_check:
        # 检查列的唯一值数量
        value_len = check_state(data, col)
        if value_len < distinct_threshold:
            temp_df = pd.DataFrame({
                'constant_rate': [0.0],
                'constant_count': [0]
            }).transpose()
            result_dfs.append(temp_df)
            constant_indices[col] = np.zeros(len(data), dtype=bool)
            continue

        # 计算变化点分组
        df = data.copy()
        # df['Group'] = (df[col] != df[col].shift()).cumsum()
        df.loc[:, 'Group'] = (df[col] != df[col].shift()).cumsum()

        df['t'] = df.index
        result = df.groupby('Group').agg(Start=('t', 'first'), End=('t', 'last'), Value=(col, 'first'))
        result['Duration'] = (result['End'] - result['Start']).dt.total_seconds()
        filtered_result = result[result['Duration'] > duration_threshold]
        
        # 直接生成掩码
        mask = df['Group'].isin(filtered_result.index).values

        count_constant = mask.sum()
        count_total = len(data)
        data_quality_rate = count_constant / count_total

        # 结果存储
        temp_df = pd.DataFrame({
            'constant_rate': [data_quality_rate],
            'constant_count': [count_constant]
        }).transpose()
        result_dfs.append(temp_df)

        constant_indices[col] = mask

    # 合并结果
    result_df = pd.concat(result_dfs, axis=1)
    result_df.columns = columns_to_check

    # 常值索引布尔 DataFrame
    constant_indices = pd.DataFrame(constant_indices, index=data.index)
    print(f'sum of constant_indices={constant_indices.sum()}')
    # 提取常值数据
    constant_data = data.loc[constant_indices.any(axis=1), columns_to_check]

    return constant_indices


