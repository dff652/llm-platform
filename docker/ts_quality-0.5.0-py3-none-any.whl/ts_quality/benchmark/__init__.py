"""
benchmark -- 轻量算法对比工具

提供三个核心函数:
- compare(): 同一数据集上运行多个算法，收集结果
- report.agreement(): 算法间一致性分析
- report.accuracy(): 有标签时计算精度指标
"""

from .compare import compare
from . import report

__all__ = ['compare', 'report']
