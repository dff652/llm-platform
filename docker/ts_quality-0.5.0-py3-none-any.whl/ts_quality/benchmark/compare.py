"""
多算法对比运行器

在同一数据集上运行指定算法，返回结果汇总表。
"""

import time
import numpy as np
import pandas as pd

# 算法名 -> (模块路径, 函数名, 默认参数)
_REGISTRY = {
    'n_sigma': {
        'module': 'ts_quality.check_outlier.n_sigma',
        'func': 'detect',
        'defaults': {'threshold': 5, 'merge_distance': 600},
    },
    'iqr_outliers': {
        'module': 'ts_quality.check_outlier.iqr_outliers',
        'func': 'detect',
        'defaults': {'threshold': 1.5, 'merge_distance': 600},
    },
    'ensemble': {
        'module': 'ts_quality.check_outlier.ensemble',
        'func': 'detect',
        'defaults': {'threshold': 1.5, 'merge_ratio': 0.01},
    },
    'wavelet': {
        'module': 'ts_quality.check_outlier.wavelet',
        'func': 'detect',
        'defaults': {'threshold': 5, 'merge_ratio': 0.01},
    },
    'isolation_forest': {
        'module': 'ts_quality.check_outlier.isolation_forest',
        'func': 'detect',
        'defaults': {'contamination': 0.01, 'merge_distance': 1200},
    },
    'stl_wavelet': {
        'module': 'ts_quality.check_outlier.stl_wavelet',
        'func': 'stl_wavelet_detect',
        'defaults': {'threshold': 8, 'downsampler': 'm4'},
    },
    'adtk_hbos': {
        'module': 'ts_quality.check_outlier.adtk_hbos',
        'func': 'detect',
        'defaults': {'bin_nums': 20},
    },
}

# 算法别名
_ALIASES = {
    'piecewise_linear': 'ensemble',
    'iforest': 'isolation_forest',
}

# 需要 DatetimeIndex 的算法
_NEEDS_DATETIME_INDEX = {'stl_wavelet', 'adtk_hbos'}

ALL_METHODS = list(_REGISTRY.keys())


def _resolve_method(name):
    """解析算法名（含别名）。"""
    name = _ALIASES.get(name, name)
    if name not in _REGISTRY:
        raise ValueError(
            f"未知算法 '{name}'，可选: {', '.join(ALL_METHODS)}"
        )
    return name


def _load_func(method):
    """延迟导入算法函数，避免 import benchmark 时加载全部算法。"""
    import importlib
    info = _REGISTRY[method]
    mod = importlib.import_module(info['module'])
    return getattr(mod, info['func'])


def _extract_indices(result, data_len):
    """
    统一提取异常索引。

    不同算法返回类型不同:
    - np.ndarray[int]: 直接使用
    - pd.DataFrame: 从 anomaly 列提取 (stl_wavelet)
    """
    if isinstance(result, np.ndarray):
        return result
    if isinstance(result, pd.DataFrame):
        # stl_wavelet 返回 DataFrame，anomaly 列为布尔或 0/1
        for col in ['anomaly', 'is_anomaly', 'outlier']:
            if col in result.columns:
                mask = result[col].astype(bool)
                return np.where(mask)[0]
        # 如果没有已知的异常列，取最后一列
        mask = result.iloc[:, -1].astype(bool)
        return np.where(mask)[0]
    if isinstance(result, pd.Series):
        return np.where(result.astype(bool))[0]
    return np.array([], dtype=int)


def compare(data, methods=None, params=None):
    """
    在同一数据集上运行多个算法，返回结果汇总表。

    Parameters
    ----------
    data : pd.DataFrame or pd.Series
        输入时间序列数据
    methods : list[str], optional
        算法名列表，默认运行全部 5 个轻量算法
        (不含 stl_wavelet/adtk_hbos，因为它们需要 DatetimeIndex)
    params : dict[str, dict], optional
        每个算法的自定义参数，如 {'n_sigma': {'threshold': 3}}

    Returns
    -------
    pd.DataFrame
        columns: method, anomaly_count, ratio, time_sec, indices
    """
    if methods is None:
        # 默认只跑不需要 DatetimeIndex 的轻量算法
        has_datetime = isinstance(
            getattr(data, 'index', None), pd.DatetimeIndex
        )
        if has_datetime:
            methods = ALL_METHODS
        else:
            methods = [m for m in ALL_METHODS if m not in _NEEDS_DATETIME_INDEX]

    params = params or {}
    data_len = len(data)
    rows = []

    for name in methods:
        method = _resolve_method(name)
        func = _load_func(method)

        # 合并默认参数和用户参数
        kw = dict(_REGISTRY[method]['defaults'])
        kw.update(params.get(name, {}))

        t0 = time.perf_counter()
        try:
            result = func(data, **kw)
            indices = _extract_indices(result, data_len)
            error = None
        except Exception as e:
            indices = np.array([], dtype=int)
            error = str(e)
        elapsed = time.perf_counter() - t0

        rows.append({
            'method': name,
            'anomaly_count': len(indices),
            'ratio': len(indices) / data_len if data_len > 0 else 0.0,
            'time_sec': round(elapsed, 4),
            'indices': indices,
            'error': error,
        })

    return pd.DataFrame(rows)
