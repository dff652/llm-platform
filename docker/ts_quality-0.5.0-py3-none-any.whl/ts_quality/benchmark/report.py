"""
结果分析报告

- agreement(): 算法间一致性分析
- accuracy(): 有标签时精度评估
"""

import itertools
import numpy as np
import pandas as pd


def agreement(compare_result):
    """
    分析多个算法结果之间的重叠度。

    Parameters
    ----------
    compare_result : pd.DataFrame
        compare() 的返回值，必须包含 method 和 indices 列

    Returns
    -------
    pd.DataFrame
        columns: method_a, method_b, overlap, only_a, only_b, jaccard
    """
    methods = compare_result['method'].tolist()
    indices_map = dict(zip(
        compare_result['method'],
        compare_result['indices'].apply(lambda x: set(x.tolist()))
    ))

    rows = []
    for a, b in itertools.combinations(methods, 2):
        set_a = indices_map[a]
        set_b = indices_map[b]
        overlap = len(set_a & set_b)
        only_a = len(set_a - set_b)
        only_b = len(set_b - set_a)
        union = len(set_a | set_b)
        jaccard = overlap / union if union > 0 else 1.0

        rows.append({
            'method_a': a,
            'method_b': b,
            'overlap': overlap,
            'only_a': only_a,
            'only_b': only_b,
            'jaccard': round(jaccard, 4),
        })

    return pd.DataFrame(rows)


def accuracy(compare_result, labels):
    """
    有标注时，计算每个算法的 precision / recall / f1。

    Parameters
    ----------
    compare_result : pd.DataFrame
        compare() 的返回值
    labels : array-like
        真实异常点索引（整数数组或列表）

    Returns
    -------
    pd.DataFrame
        columns: method, precision, recall, f1, time_sec
    """
    label_set = set(np.asarray(labels).tolist())
    if len(label_set) == 0:
        raise ValueError("labels 不能为空")

    rows = []
    for _, row in compare_result.iterrows():
        pred_set = set(row['indices'].tolist())

        tp = len(pred_set & label_set)
        fp = len(pred_set - label_set)
        fn = len(label_set - pred_set)

        precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        f1 = (2 * precision * recall / (precision + recall)
              if (precision + recall) > 0 else 0.0)

        rows.append({
            'method': row['method'],
            'precision': round(precision, 4),
            'recall': round(recall, 4),
            'f1': round(f1, 4),
            'time_sec': row['time_sec'],
        })

    return pd.DataFrame(rows)
