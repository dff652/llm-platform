"""
工具函数模块

包含核心指标计算中使用的通用工具函数
"""

import functools
import time
import logging
import pandas as pd
import numpy as np


def timer_decorator(func):
    """
    装饰器用于记录函数运行时间
    
    Parameters
    ----
    func : function
        要装饰的函数
        
    Returns
    ----
    wrapper_timer : function
        装饰后的函数
    """

    @functools.wraps(func)
    def wrapper_timer(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        run_time = end_time - start_time
        logging.info(f"Function {func.__name__!r} took {run_time:.4f} seconds")
        return result

    return wrapper_timer


def check_dataframe(df):
    """
    检查单列DataFrame在去除空值后是否含有超过100行数据
    
    Parameters
    ----
    df : pd.DataFrame
        要检查的DataFrame
        
    Returns
    ----
    None
        
    Exception
    ----
    ValueError
        当数据行数不足100行时抛出
    """
    # 去除空值
    df_cleaned = df.dropna()

    # 检查行数是否超过100
    if len(df_cleaned) <= 100:
        raise ValueError("DataFrame中的数据行数不足100行！")


def check_empty(df):
    """
    检查DataFrame是否为空
    
    Parameters
    ----
    df : pd.DataFrame
        要检查的DataFrame
        
    Returns
    ----
    bool
        如果DataFrame为空返回True，否则返回False
    """
    if df.empty:
        # raise ValueError("DataFrame为空！")
        print("DataFrame为空！")
        return True


def check_state(data, col):
    """
    检查数据列的唯一值数量
    
    Parameters
    ----
    data : pd.DataFrame
        输入的数据集
    col : str
        列名
        
    Returns
    ----
    int
        唯一值的数量
    """
    values_unique = data[col].unique()
    return len(values_unique)


def check_unique(data):
    """
    检查数据的所有列的唯一值数量
    
    Parameters
    ----
    data : pd.DataFrame
        输入的数据集
        
    Returns
    ----
    int
        唯一值的数量
    """
    columns_to_check = data.columns
    for col in columns_to_check:
        values_unique = data[col].unique()
    return len(values_unique) 

@timer_decorator 
def dead_value_post_detection(data, column_name, duration_threshold=3600):
    """
    对指定列进行死值后检测
    
    Parameters
    ----
    data : pd.DataFrame
        输入的数据集
    column_name : str
        要检测的列名
    duration_threshold : int, optional
        死值的持续时间阈值，默认为3600秒
        
    Returns
    ----
    filtered_result : pd.DataFrame
        满足条件的死值段信息
    """
    # 确保时间索引是 DatetimeIndex 类型
    if not isinstance(data.index, pd.DatetimeIndex):
        raise ValueError("数据的索引需要是 DatetimeIndex 类型")

    # 复制数据并初始化结果掩码
    df = data.copy()
    df['Group'] = (df[column_name] != df[column_name].shift()).cumsum()  # 分组

    # 计算每组的起始、结束时间
    df['t'] = df.index
    result = df.groupby('Group').agg(Start=('t', 'first'), End=('t', 'last'), Value=(column_name, 'first'))

    # 计算持续时间（单位：秒）
    result['Duration'] = (result['End'] - result['Start']).dt.total_seconds()

    # 筛选满足持续时间和列值为 True 的组
    filtered_result = result[(result['Duration'] > duration_threshold) & (result['Value'] == True)]

    return filtered_result 